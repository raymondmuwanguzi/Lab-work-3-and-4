Lab 4 - Input/output, files. Based on Lab 2 (student semester model). Java 8+, MVC.

Run (Eclipse): import the project, run lab4.Main. Working directory must be the project root
(it contains settings.properties). Command line: javac -d bin $(find src -name "*.java");
java -cp bin lab4.Main [path-to-settings]

Settings (settings.properties): login, password, group (root|user), debug, autotests, database, log.
Default login: admin / admin123 (group root).
- group root: menu gets "Debug" and "Autotests"; user: no such items.
- debug=true: log is written (any group). Root can switch it in Debug menu.
- autotests=true: tests run before the main menu, results to console and log (always logged).

Menu: demo (Lab 2), report, read DB, write DB, list (get), add (put, any number),
change, delete (del), [Debug], [Autotests], exit (asks to save unsaved changes).
DB file (students.db): text, UTF-8, records TEACHER/PARENT/STUDENT/GRADE with unique ids.
Log (application.log): appended, with time stamps.

Packages: model (data + StudentDatabase + file storage), view (ConsoleView),
controller, config (settings), util (AppLogger), autotest.
