package lab4.config;

import java.io.IOException;

/** The settings file is missing or contains wrong values. */
public class SettingsException extends IOException {

    private static final long serialVersionUID = 1L;

    public SettingsException(String message) {
        super(message);
    }
}
