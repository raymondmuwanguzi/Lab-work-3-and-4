package lab4.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * Loads {@link Settings} from a {@code key=value} file (java.util.Properties format, UTF-8).
 *
 * <pre>
 * login      - name of the user (required)
 * password   - password of the user (required)
 * group      - root or user (required)
 * debug      - true/false: write the log (required)
 * autotests  - true/false: run the autotests before the main menu (required)
 * database   - path of the "database" file (optional, default students.db)
 * log        - path of the log file (optional, default application.log)
 * </pre>
 * Leading and trailing spaces of the values are ignored.
 */
public final class SettingsLoader {

    public static final String DEFAULT_DATABASE = "students.db";
    public static final String DEFAULT_LOG = "application.log";

    private SettingsLoader() {
    }

    public static Settings load(File file) throws IOException {
        if (!file.isFile()) {
            throw new FileNotFoundException("Settings file not found: " + file.getAbsolutePath());
        }
        Properties props = new Properties();
        try (Reader in = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8)) {
            props.load(in);
        } catch (IllegalArgumentException e) {
            // thrown by Properties.load for a malformed \\uxxxx escape
            throw new SettingsException("Settings file is malformed: " + e.getMessage());
        }
        String login = required(props, "login");
        String password = required(props, "password");
        UserGroup group;
        try {
            group = UserGroup.parse(required(props, "group"));
        } catch (IllegalArgumentException e) {
            throw new SettingsException("Wrong value of 'group': " + e.getMessage());
        }
        boolean debug = requiredBoolean(props, "debug");
        boolean autotests = requiredBoolean(props, "autotests");
        File database = new File(optional(props, "database", DEFAULT_DATABASE));
        File log = new File(optional(props, "log", DEFAULT_LOG));
        return new Settings(login, password, group, debug, autotests, database, log);
    }

    private static String required(Properties props, String key) throws SettingsException {
        String value = props.getProperty(key);
        if (value == null || value.trim().isEmpty()) {
            throw new SettingsException("Setting '" + key + "' is missing or empty");
        }
        return value.trim();
    }

    private static String optional(Properties props, String key, String defaultValue) {
        String value = props.getProperty(key);
        return value == null || value.trim().isEmpty() ? defaultValue : value.trim();
    }

    private static boolean requiredBoolean(Properties props, String key) throws SettingsException {
        String value = required(props, key);
        if (value.equalsIgnoreCase("true")) {
            return true;
        }
        if (value.equalsIgnoreCase("false")) {
            return false;
        }
        throw new SettingsException("Setting '" + key + "' must be true or false but is '" + value + "'");
    }
}
