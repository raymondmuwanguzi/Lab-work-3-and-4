package lab4.config;

import java.util.Locale;

/** Group (rights) of the user: root = developer, user = operator. */
public enum UserGroup {
    ROOT("root"),
    USER("user");

    private final String title;

    UserGroup(String title) {
        this.title = title;
    }

    /** Parses "root" or "user" (case-insensitive). */
    public static UserGroup parse(String text) {
        if (text != null) {
            String t = text.trim().toLowerCase(Locale.ROOT);
            for (UserGroup g : values()) {
                if (g.title.equals(t)) {
                    return g;
                }
            }
        }
        throw new IllegalArgumentException("Unknown user group: '" + text + "' (use root or user)");
    }

    @Override
    public String toString() {
        return title;
    }
}
