package lab4.config;

import java.io.File;

/** Immutable settings of the program, read from the settings file at the start. */
public final class Settings {

    private final String login;
    private final String password;
    private final UserGroup group;
    private final boolean debug;
    private final boolean autotests;
    private final File databaseFile;
    private final File logFile;

    public Settings(String login, String password, UserGroup group, boolean debug, boolean autotests,
            File databaseFile, File logFile) {
        this.login = login;
        this.password = password;
        this.group = group;
        this.debug = debug;
        this.autotests = autotests;
        this.databaseFile = databaseFile;
        this.logFile = logFile;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public UserGroup getGroup() {
        return group;
    }

    public boolean isRoot() {
        return group == UserGroup.ROOT;
    }

    /** Debug mode: the log is written. */
    public boolean isDebug() {
        return debug;
    }

    /** Autotests mode: the tests are run before the main menu. */
    public boolean isAutotests() {
        return autotests;
    }

    public File getDatabaseFile() {
        return databaseFile;
    }

    public File getLogFile() {
        return logFile;
    }
}
