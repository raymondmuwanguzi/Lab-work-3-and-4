package lab4.controller;

/** Items of the main menu. The items marked "root only" are shown only to the group root. */
public enum MenuAction {
    DEMO("Run semester demonstration (Lab 2)", false),
    REPORT("Show semester report", false),
    READ("Read database from file", false),
    WRITE("Write database to file", false),
    LIST("List students", false),
    ADD("Add students", false),
    CHANGE("Change student", false),
    DELETE("Delete student", false),
    DEBUG("Debug", true),
    AUTOTESTS("Autotests", true);

    private final String title;
    private final boolean rootOnly;

    MenuAction(String title, boolean rootOnly) {
        this.title = title;
        this.rootOnly = rootOnly;
    }

    public String getTitle() {
        return title;
    }

    public boolean isRootOnly() {
        return rootOnly;
    }
}
