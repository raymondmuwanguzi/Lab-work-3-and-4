package lab4.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import lab4.autotest.AutoTests;
import lab4.autotest.TestResult;
import lab4.config.Settings;
import lab4.model.SemesterModel;
import lab4.model.StudentDatabase;
import lab4.util.AppLogger;
import lab4.view.ConsoleView;
import lab4.view.InputClosedException;

/**
 * Main controller: login, welcome message, autotests at the start, the main menu and the
 * "Debug" and "Autotests" items that are available to the group root only.
 */
public class MainController {

    public static final int EXIT_OK = 0;
    public static final int EXIT_LOGIN_FAILED = 2;

    private static final int MAX_LOGIN_ATTEMPTS = 3;
    private static final int LOG_TAIL_RECORDS = 20;

    private final Settings settings;
    private final File settingsFile;
    private final AppLogger logger;
    private final StudentDatabase database;
    private final ConsoleView view;
    private final SemesterController semesterController;
    private final StudentController studentController;

    public MainController(Settings settings, File settingsFile, AppLogger logger, StudentDatabase database,
            ConsoleView view, SemesterController semesterController, StudentController studentController) {
        this.settings = settings;
        this.settingsFile = settingsFile;
        this.logger = logger;
        this.database = database;
        this.view = view;
        this.semesterController = semesterController;
        this.studentController = studentController;
    }

    /**
     * Runs the program.
     *
     * @return the exit code of the program: 0 if all is well, 2 if the login failed
     */
    public int run() {
        boolean started = false;
        try {
            if (!authenticate()) {
                view.showMessage("Login failed " + MAX_LOGIN_ATTEMPTS + " times. The program is closed.");
                logger.error("Program terminated: login failed " + MAX_LOGIN_ATTEMPTS + " times");
                return EXIT_LOGIN_FAILED;
            }
            started = true;
            logger.info("Program started: login=" + settings.getLogin() + ", group=" + settings.getGroup()
                    + ", debug=" + settings.isDebug() + ", autotests=" + settings.isAutotests());
            logger.debug("Environment: java=" + System.getProperty("java.version")
                    + ", os=" + System.getProperty("os.name") + ", directory=" + System.getProperty("user.dir")
                    + ", settings=" + settingsFile.getAbsolutePath()
                    + ", database=" + database.getFile().getAbsolutePath()
                    + ", log=" + logger.getFile().getAbsolutePath());
            view.showWelcome(settings.getLogin());
            if (settings.isAutotests()) {
                runAutotests("autotests=true in the settings file");
            }
            menuLoop();
            return EXIT_OK;
        } catch (InputClosedException e) {
            if (started) {
                logger.info("The input stream was closed - the program is stopped");
                return EXIT_OK;
            }
            logger.error("Program terminated: the input stream was closed during login");
            return EXIT_LOGIN_FAILED;
        } finally {
            if (started) {
                logger.info("Program finished: login=" + settings.getLogin());
            }
        }
    }

    // ------------------------------------------------------------------ login

    private boolean authenticate() {
        view.showTitle("LOGIN");
        for (int attempt = 1; attempt <= MAX_LOGIN_ATTEMPTS; attempt++) {
            String login = view.readLine("Login: ");
            String password = view.readPassword("Password: ");
            if (settings.getLogin().equals(login) && settings.getPassword().equals(password)) {
                return true;
            }
            view.showError("Wrong login or password (attempt " + attempt + " of " + MAX_LOGIN_ATTEMPTS + ").");
            logger.error("Failed login attempt " + attempt + " of " + MAX_LOGIN_ATTEMPTS
                    + " for login '" + login + "'");
        }
        return false;
    }

    // ------------------------------------------------------------------ main menu

    /** The menu items available to the current user: root additionally gets Debug and Autotests. */
    private List<MenuAction> availableActions() {
        List<MenuAction> actions = new ArrayList<MenuAction>();
        for (MenuAction action : MenuAction.values()) {
            if (!action.isRootOnly() || settings.isRoot()) {
                actions.add(action);
            }
        }
        return actions;
    }

    private void menuLoop() {
        while (true) {
            List<MenuAction> actions = availableActions();
            List<String> titles = new ArrayList<String>();
            for (MenuAction action : actions) {
                titles.add(action.getTitle());
            }
            view.showMenu("MAIN MENU", titles, "Exit");
            int choice = view.readInt("Your choice: ", 0, actions.size());
            if (choice == 0) {
                if (confirmExit()) {
                    return;
                }
                continue;
            }
            execute(actions.get(choice - 1));
        }
    }

    private void execute(MenuAction action) {
        logger.debug("Menu item selected: " + action.getTitle());
        if (action.isRootOnly() && !settings.isRoot()) {
            view.showError("This item is available to the group root only.");
            logger.error("Access denied: login=" + settings.getLogin() + " tried to use '" + action.getTitle() + "'");
            return;
        }
        try {
            switch (action) {
                case DEMO:
                    semesterController.runDemo();
                    break;
                case REPORT:
                    semesterController.showReport();
                    break;
                case READ:
                    studentController.readDatabase();
                    break;
                case WRITE:
                    studentController.writeDatabase();
                    break;
                case LIST:
                    studentController.listStudents();
                    break;
                case ADD:
                    studentController.addStudents();
                    break;
                case CHANGE:
                    studentController.changeStudent();
                    break;
                case DELETE:
                    studentController.deleteStudent();
                    break;
                case DEBUG:
                    debugMenu();
                    break;
                case AUTOTESTS:
                    runAutotests("menu item 'Autotests' used by " + settings.getLogin());
                    break;
                default:
                    break;
            }
        } catch (InputClosedException e) {
            throw e;
        } catch (RuntimeException e) {
            view.showError("Unexpected error: " + e);
            logger.error("Unexpected error in the menu item '" + action.getTitle() + "'", e);
        }
    }

    /** Asks what to do with the unsaved changes; returns true if the program may be closed. */
    private boolean confirmExit() {
        if (!database.isDirty()) {
            return true;
        }
        view.showMenu("UNSAVED CHANGES", Arrays.asList("Write to the database file and exit", "Exit without saving"),
                "Cancel (stay in the program)");
        int choice = view.readInt("Your choice: ", 0, 2);
        if (choice == 0) {
            logger.debug("Exit cancelled by the user");
            return false;
        }
        if (choice == 1) {
            return studentController.writeDatabase();
        }
        logger.info("Exit without saving the changes of the list");
        return true;
    }

    // ------------------------------------------------------------------ autotests

    /** Runs the autotests, prints the results to the console and writes them to the log. */
    private void runAutotests(String reason) {
        view.showTitle("AUTOTESTS");
        logger.test("Autotests started (" + reason + ")");
        List<TestResult> results = AutoTests.runAll();
        int failed = 0;
        for (TestResult result : results) {
            if (!result.isPassed()) {
                failed++;
            }
            logger.test(result.toString());
        }
        logger.test("Autotests finished: passed=" + (results.size() - failed) + ", failed=" + failed);
        view.showTestResults(results);
    }

    // ------------------------------------------------------------------ debug (root only)

    private void debugMenu() {
        while (true) {
            String toggle = logger.isEnabled() ? "Turn debug logging OFF (it is ON now)"
                    : "Turn debug logging ON (it is OFF now)";
            view.showMenu("DEBUG", Arrays.asList("Show debug information", toggle,
                    "Show the last " + LOG_TAIL_RECORDS + " log records"), "Back to the main menu");
            int choice = view.readInt("Your choice: ", 0, 3);
            switch (choice) {
                case 1:
                    showDebugInfo();
                    break;
                case 2:
                    toggleLogging();
                    break;
                case 3:
                    showLogTail();
                    break;
                default:
                    return;
            }
        }
    }

    private void showDebugInfo() {
        SemesterModel model = database.getModel();
        File db = database.getFile();
        File log = logger.getFile();
        List<String> lines = new ArrayList<String>();
        lines.add("User: " + settings.getLogin() + " (group " + settings.getGroup() + ")");
        lines.add("Settings file: " + settingsFile.getAbsolutePath());
        lines.add("Settings: debug=" + settings.isDebug() + ", autotests=" + settings.isAutotests());
        lines.add("Debug logging is now: " + (logger.isEnabled() ? "ON" : "OFF"));
        lines.add("Log file: " + log.getAbsolutePath() + fileSize(log));
        lines.add("Database file: " + db.getAbsolutePath() + fileSize(db));
        lines.add("Unsaved changes in the list: " + (database.isDirty() ? "yes" : "no"));
        lines.add("Model: " + StudentController.describe(model) + ", weeks=" + model.getWeeks());
        lines.add("Java " + System.getProperty("java.version") + ", " + System.getProperty("os.name")
                + ", working directory " + System.getProperty("user.dir"));
        view.showLines("DEBUG INFORMATION", lines);
        logger.debug("Debug information shown: " + StudentController.describe(model)
                + ", unsaved=" + database.isDirty());
    }

    private void toggleLogging() {
        if (logger.isEnabled()) {
            logger.info("Debug logging turned OFF from the Debug menu by " + settings.getLogin());
            logger.setEnabled(false);
            view.showMessage("Debug logging is OFF now (the autotest results are still logged).");
        } else {
            logger.setEnabled(true);
            logger.info("Debug logging turned ON from the Debug menu by " + settings.getLogin());
            view.showMessage("Debug logging is ON now. Log file: " + logger.getFile().getAbsolutePath());
        }
    }

    private void showLogTail() {
        try {
            view.showLines("LAST LOG RECORDS", logger.tail(LOG_TAIL_RECORDS));
        } catch (IOException e) {
            view.showError("Cannot read the log file: " + e.getMessage());
            logger.error("Cannot read the log file", e);
        }
    }

    private static String fileSize(File file) {
        return file.isFile() ? " (" + file.length() + " bytes)" : " (does not exist yet)";
    }
}
