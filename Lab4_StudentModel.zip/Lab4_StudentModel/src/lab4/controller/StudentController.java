package lab4.controller;

import java.io.File;
import java.io.IOException;
import java.util.Collections;

import lab4.model.Gender;
import lab4.model.Parent;
import lab4.model.SemesterModel;
import lab4.model.Student;
import lab4.model.StudentDatabase;
import lab4.util.AppLogger;
import lab4.view.ConsoleView;

/**
 * Controller of the "database" operations: read and write the file, list, add, change and
 * delete students. All operations are chosen in the main menu.
 */
public class StudentController {

    private static final int MAX_AGE = 120;
    private static final int MAX_STUDENTS_AT_ONCE = 1000;

    private final StudentDatabase database;
    private final ConsoleView view;
    private final AppLogger logger;

    public StudentController(StudentDatabase database, ConsoleView view, AppLogger logger) {
        this.database = database;
        this.view = view;
        this.logger = logger;
    }

    /** Short description of the content of the model for messages and log records. */
    public static String describe(SemesterModel model) {
        return "teachers=" + model.getTeachers().size() + ", parents=" + model.getParents().size()
                + ", students=" + model.getStudents().size() + ", grades=" + model.getGradeCount();
    }

    private static String describe(Student s) {
        Parent p = s.getParent();
        return "id=" + s.getId() + ", name=" + s.getName() + ", age=" + s.getAge() + ", gender=" + s.getGender()
                + ", parent=" + (p == null ? "-" : p.getId() + "/" + p.getName() + "/" + p.getAge() + "/" + p.getGender());
    }

    // ------------------------------------------------------------------ file operations

    /** Reads the list of students from the file and shows it on the console. */
    public void readDatabase() {
        File file = database.getFile();
        if (database.isDirty()
                && !view.confirm("There are unsaved changes; reading will discard them. Continue? (y/n): ")) {
            view.showMessage("Reading cancelled.");
            logger.debug("Reading of the database cancelled by the user (unsaved changes)");
            return;
        }
        try {
            database.read();
            SemesterModel model = database.getModel();
            logger.info("Database read: file=" + file.getAbsolutePath() + ", " + describe(model));
            view.showMessage("Database read from " + file.getAbsolutePath());
            view.showModelSummary(model);
            view.showStudents(database.get());
        } catch (IOException e) {
            view.showError("Cannot read the database: " + e.getMessage());
            logger.error("Database read failed: file=" + file.getAbsolutePath(), e);
        }
    }

    /**
     * Writes the list of students to the file.
     *
     * @return true if the file was written
     */
    public boolean writeDatabase() {
        File file = database.getFile();
        SemesterModel model = database.getModel();
        if (model.getStudents().isEmpty() && !view.confirm(
                "The list contains no students; the file will be replaced by an empty database. Continue? (y/n): ")) {
            view.showMessage("Writing cancelled.");
            logger.debug("Writing of the database cancelled by the user (empty list)");
            return false;
        }
        try {
            database.write();
            logger.info("Database written: file=" + file.getAbsolutePath() + ", " + describe(model));
            view.showMessage("Database written to " + file.getAbsolutePath());
            view.showModelSummary(model);
            return true;
        } catch (IOException e) {
            view.showError("Cannot write the database: " + e.getMessage());
            logger.error("Database write failed: file=" + file.getAbsolutePath(), e);
            return false;
        }
    }

    // ------------------------------------------------------------------ list operations

    public void listStudents() {
        view.showStudents(database.get());
        logger.debug("Student list shown: " + database.get().size() + " student(s)");
    }

    /** Adds any number of new students; their data is entered on the console. */
    public void addStudents() {
        view.showTitle("ADD STUDENTS");
        int count = view.readInt("How many students do you want to add? (0 = cancel): ", 0, MAX_STUDENTS_AT_ONCE);
        int added = 0;
        for (int i = 1; i <= count; i++) {
            view.showMessage("");
            view.showMessage("Student " + i + " of " + count + ":");
            if (addOne()) {
                added++;
            }
        }
        if (count == 0) {
            view.showMessage("Nothing added.");
            return;
        }
        view.showMessage("");
        view.showMessage(added + " of " + count + " student(s) added. The list is changed in the memory only -"
                + " use 'Write database to file' to save it.");
        logger.debug("Adding finished: requested=" + count + ", added=" + added);
    }

    private boolean addOne() {
        String name = view.readNonEmpty("  Student name: ");
        int age = view.readInt("  Student age: ", 1, MAX_AGE);
        Gender gender = view.readGender("  Student gender (male/female): ");
        Parent parent = askParent();
        try {
            Student student = database.put(new Student(name, age, gender), parent);
            view.showMessage("  Added: " + student.getName() + ", id " + student.getId()
                    + ", parent id " + parent.getId());
            logger.info("Database put: " + describe(student));
            return true;
        } catch (IllegalArgumentException | IllegalStateException e) {
            view.showError("The student was not added: " + e.getMessage());
            logger.error("Database put failed", e);
            return false;
        }
    }

    /** Asks for the parent of a new student: an existing one (by id) or a new one. */
    private Parent askParent() {
        while (true) {
            int id = view.readInt("  Parent: id of an existing parent or 0 for a new parent: ", 0, Integer.MAX_VALUE);
            if (id == 0) {
                String name = view.readNonEmpty("  Parent name: ");
                int age = view.readInt("  Parent age: ", 1, MAX_AGE);
                Gender gender = view.readGender("  Parent gender (male/female): ");
                return new Parent(name, age, gender);
            }
            Parent parent = database.getModel().findParent(id);
            if (parent == null) {
                view.showError("There is no parent with id " + id + ".");
            } else if (parent.isReviewed()) {
                view.showError(parent.getName() + " has already paid the bonuses; choose another parent or 0 for a new one.");
            } else {
                return parent;
            }
        }
    }

    /** Changes the data of one student (and of his parent); an empty answer keeps the old value. */
    public void changeStudent() {
        view.showTitle("CHANGE STUDENT");
        Student student = chooseStudent("ID of the student to change (0 = cancel): ");
        if (student == null) {
            return;
        }
        view.showMessage("Leave a value empty to keep the current one.");
        String name = emptyToNull(view.readLine("  Name [" + student.getName() + "]: "));
        Integer age = view.readOptionalInt("  Age [" + student.getAge() + "]: ", 1, MAX_AGE);
        Gender gender = view.readOptionalGender("  Gender [" + student.getGender() + "]: ");
        String parentName = null;
        Integer parentAge = null;
        Gender parentGender = null;
        Parent parent = student.getParent();
        if (parent != null) {
            parentName = emptyToNull(view.readLine("  Parent name [" + parent.getName() + "]: "));
            parentAge = view.readOptionalInt("  Parent age [" + parent.getAge() + "]: ", 1, MAX_AGE);
            parentGender = view.readOptionalGender("  Parent gender [" + parent.getGender() + "]: ");
        }
        String before = describe(student);
        try {
            database.change(student.getId(), name, age, gender, parentName, parentAge, parentGender);
            view.showMessage("Student changed:");
            view.showStudents(Collections.singletonList(student));
            logger.info("Database change: before [" + before + "], after [" + describe(student) + "]");
        } catch (IllegalArgumentException | IllegalStateException e) {
            view.showError("The student was not changed: " + e.getMessage());
            logger.error("Database change failed for student id=" + student.getId(), e);
        }
    }

    /** Deletes one student after a confirmation. */
    public void deleteStudent() {
        view.showTitle("DELETE STUDENT");
        Student student = chooseStudent("ID of the student to delete (0 = cancel): ");
        if (student == null) {
            return;
        }
        if (!view.confirm("Delete " + student.getName() + " (id " + student.getId()
                + ") with all grades? (y/n): ")) {
            view.showMessage("Deletion cancelled.");
            logger.debug("Deletion of student id=" + student.getId() + " cancelled by the user");
            return;
        }
        String info = describe(student);
        Student removed = database.del(student.getId());
        if (removed == null) {
            view.showError("The student was not found.");
            logger.error("Database del failed: no student with id=" + student.getId());
            return;
        }
        view.showMessage("Student deleted. The list is changed in the memory only -"
                + " use 'Write database to file' to save it.");
        logger.info("Database del: " + info);
    }

    /** Shows the list and asks for the id of an existing student; returns null on cancel. */
    private Student chooseStudent(String prompt) {
        if (database.get().isEmpty()) {
            view.showMessage("The list of students is empty. Add students or read the database first.");
            return null;
        }
        view.showStudents(database.get());
        while (true) {
            int id = view.readInt(prompt, 0, Integer.MAX_VALUE);
            if (id == 0) {
                view.showMessage("Cancelled.");
                return null;
            }
            Student student = database.get(id);
            if (student != null) {
                return student;
            }
            view.showError("There is no student with id " + id + ".");
        }
    }

    private static String emptyToNull(String text) {
        return text.isEmpty() ? null : text;
    }
}
