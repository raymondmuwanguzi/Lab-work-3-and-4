package lab4.autotest;

/** Result of one autotest. */
public final class TestResult {

    private final String name;
    private final boolean passed;
    private final String details;

    public TestResult(String name, boolean passed, String details) {
        this.name = name;
        this.passed = passed;
        this.details = details;
    }

    public String getName() {
        return name;
    }

    public boolean isPassed() {
        return passed;
    }

    /** "ok" for a passed test, the description of the problem for a failed one. */
    public String getDetails() {
        return details;
    }

    @Override
    public String toString() {
        return (passed ? "PASS " : "FAIL ") + name + (passed ? "" : " - " + details);
    }
}
