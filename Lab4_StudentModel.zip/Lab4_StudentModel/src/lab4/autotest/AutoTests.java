package lab4.autotest;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import lab4.config.Settings;
import lab4.config.SettingsException;
import lab4.config.SettingsLoader;
import lab4.config.UserGroup;
import lab4.model.DatabaseFormatException;
import lab4.model.Gender;
import lab4.model.Grade;
import lab4.model.ModelFileStorage;
import lab4.model.Parent;
import lab4.model.ParentMood;
import lab4.model.SemesterModel;
import lab4.model.Student;
import lab4.model.StudentDatabase;
import lab4.model.Subject;
import lab4.model.Teacher;
import lab4.util.AppLogger;

/**
 * Autotests: check the algorithms of the program on control data with known results.
 * The tests use temporary files only and never touch the real database, settings or log.
 */
public final class AutoTests {

    /** One check; any exception or AssertionError means "failed". */
    private interface Check {
        void run() throws Exception;
    }

    private final List<TestResult> results = new ArrayList<TestResult>();

    private AutoTests() {
    }

    /** Runs all tests and returns their results in the order of execution. */
    public static List<TestResult> runAll() {
        AutoTests tests = new AutoTests();
        tests.execute();
        return tests.results;
    }

    private void execute() {
        test("ParentMood: status and bonus by the average grade", this::parentMoodThresholds);
        test("Student: average grades on control grades", this::studentAverages);
        test("Grades: at most 10 per subject, at most one per week", this::gradeLimits);
        test("Grade: value must be in range 2..5", this::gradeRange);
        test("Parent: bonuses of the control model are paid once", this::bonusesPaidOnce);
        test("Parent with two children: status by the mean of averages", this::parentWithTwoChildren);
        test("Database file: write and read back the control model", this::fileRoundTrip);
        test("Database operations: put / get / change / del", this::databaseOperations);
        test("Database file: damaged files are rejected", this::damagedFiles);
        test("Settings file: parsing and validation", this::settingsParsing);
        test("Log: append, time stamps, debug flag", this::loggerBehaviour);
    }

    private void test(String name, Check check) {
        try {
            check.run();
            results.add(new TestResult(name, true, "ok"));
        } catch (AssertionError e) {
            results.add(new TestResult(name, false, String.valueOf(e.getMessage())));
        } catch (Exception e) {
            results.add(new TestResult(name, false, "unexpected exception " + e));
        }
    }

    // ------------------------------------------------------------------ control data

    /**
     * Control model: teachers Math and Physics; students Alice (average 14/3), Bob (4.0) and
     * Carol (3.0); parent A has Alice, parent B has Bob and Carol; bonuses are settled.
     * Expected: Alice 10, Bob 5, Carol 0; parent A joyful (10), parent B gloomy (mean 3.5, total 5).
     */
    private static SemesterModel controlModel() {
        SemesterModel m = new SemesterModel(12);
        Teacher math = new Teacher("Math Teacher", 40, Gender.MALE, new Subject("Mathematics"));
        Teacher phys = new Teacher("Physics Teacher", 45, Gender.FEMALE, new Subject("Physics"));
        m.addTeacher(math);
        m.addTeacher(phys);

        Student alice = new Student("Alice; \"A\" \\ Test", 19, Gender.FEMALE);
        Student bob = new Student("Bob", 20, Gender.MALE);
        Student carol = new Student("Carol", 18, Gender.FEMALE);
        Parent parentA = new Parent("Parent A\nsecond line", 45, Gender.MALE);
        Parent parentB = new Parent("Parent B", 47, Gender.FEMALE);
        parentA.addChild(alice);
        parentB.addChild(bob);
        parentB.addChild(carol);
        m.addStudent(alice);
        m.addStudent(bob);
        m.addStudent(carol);
        m.addParent(parentA);
        m.addParent(parentB);

        math.grade(alice, 1, 5);
        math.grade(alice, 2, 5);
        phys.grade(alice, 1, 4);
        math.grade(bob, 1, 4);
        phys.grade(bob, 2, 4);
        math.grade(carol, 3, 3);
        phys.grade(carol, 3, 3);
        m.settleBonuses();
        return m;
    }

    // ------------------------------------------------------------------ tests

    private void parentMoodThresholds() {
        assertEquals("status for average 0.0", ParentMood.GLOOMY, ParentMood.forAverage(0.0));
        assertEquals("status for average 3.99", ParentMood.GLOOMY, ParentMood.forAverage(3.99));
        assertEquals("status for average 4.0", ParentMood.SATISFIED, ParentMood.forAverage(4.0));
        assertEquals("status for average 4.59", ParentMood.SATISFIED, ParentMood.forAverage(4.59));
        assertEquals("status for average 4.6", ParentMood.JOYFUL, ParentMood.forAverage(4.6));
        assertEquals("status for average 5.0", ParentMood.JOYFUL, ParentMood.forAverage(5.0));
        assertEquals("bonus of a gloomy parent", 0, ParentMood.GLOOMY.getBonus());
        assertEquals("bonus of a satisfied parent", 5, ParentMood.SATISFIED.getBonus());
        assertEquals("bonus of a joyful parent", 10, ParentMood.JOYFUL.getBonus());
    }

    private void studentAverages() {
        Subject math = new Subject("Mathematics");
        Subject phys = new Subject("Physics");
        Teacher tm = new Teacher("T1", 40, Gender.MALE, math);
        Teacher tp = new Teacher("T2", 41, Gender.FEMALE, phys);
        Student s = new Student("S", 19, Gender.MALE);
        assertNear("average without grades", 0.0, s.getAverageGrade());
        tm.grade(s, 1, 5);
        tm.grade(s, 2, 4);
        tm.grade(s, 3, 3);
        tp.grade(s, 1, 5);
        assertNear("average in Mathematics (5, 4, 3)", 4.0, s.getAverageGrade(math));
        assertNear("average in Physics (5)", 5.0, s.getAverageGrade(phys));
        assertNear("average over all subjects (5, 4, 3, 5)", 4.25, s.getAverageGrade());
        assertEquals("number of grades", 4, s.getTotalGradeCount());
    }

    private void gradeLimits() {
        final Teacher t = new Teacher("T", 40, Gender.MALE, new Subject("History"));
        final Student s = new Student("S", 19, Gender.MALE);
        for (int week = 1; week <= Student.MAX_GRADES_PER_SUBJECT; week++) {
            assertTrue("teacher can grade in week " + week, t.canGrade(s, week));
            t.grade(s, week, 4);
        }
        assertEquals("number of grades", 10, s.getGradeCount(t.getSubject()));
        assertTrue("11th grade is not allowed", !t.canGrade(s, 11));
        expectThrows(IllegalStateException.class, "11th grade", () -> t.grade(s, 11, 4));

        final Student other = new Student("S2", 19, Gender.FEMALE);
        t.grade(other, 3, 5);
        expectThrows(IllegalStateException.class, "second grade in the same week",
                () -> t.grade(other, 3, 4));
    }

    private void gradeRange() {
        final Subject subject = new Subject("English");
        final Teacher teacher = new Teacher("T", 40, Gender.MALE, subject);
        assertEquals("lowest grade", 2, new Grade(2, 1, subject, teacher).getValue());
        assertEquals("highest grade", 5, new Grade(5, 1, subject, teacher).getValue());
        expectThrows(IllegalArgumentException.class, "grade 1", () -> new Grade(1, 1, subject, teacher));
        expectThrows(IllegalArgumentException.class, "grade 6", () -> new Grade(6, 1, subject, teacher));
        expectThrows(IllegalArgumentException.class, "week 0", () -> new Grade(4, 0, subject, teacher));
    }

    private void bonusesPaidOnce() {
        SemesterModel m = controlModel();
        assertEquals("bonus of Alice", 10, m.findStudent(1).getBonus());
        assertEquals("bonus of Bob", 5, m.findStudent(2).getBonus());
        assertEquals("bonus of Carol", 0, m.findStudent(3).getBonus());
        assertEquals("status of parent A", ParentMood.JOYFUL, m.findParent(1).getMood());
        assertEquals("total paid by parent A", 10, m.findParent(1).getTotalBonusPaid());
        m.settleBonuses(); // a second settlement must not pay again
        assertEquals("bonus of Alice after the second settlement", 10, m.findStudent(1).getBonus());
        assertEquals("total paid by parent A after the second settlement", 10,
                m.findParent(1).getTotalBonusPaid());
    }

    private void parentWithTwoChildren() {
        SemesterModel m = controlModel();
        Parent b = m.findParent(2);
        assertEquals("number of children of parent B", 2, b.getChildren().size());
        assertEquals("status of parent B (mean of 4.0 and 3.0 is 3.5)", ParentMood.GLOOMY, b.getMood());
        assertEquals("total paid by parent B (5 + 0)", 5, b.getTotalBonusPaid());
    }

    private void fileRoundTrip() throws IOException {
        File f = File.createTempFile("lab4-roundtrip", ".db");
        try {
            SemesterModel original = controlModel();
            ModelFileStorage.write(original, f);
            SemesterModel copy = ModelFileStorage.read(f);

            assertEquals("weeks", original.getWeeks(), copy.getWeeks());
            assertEquals("teachers", 2, copy.getTeachers().size());
            assertEquals("parents", 2, copy.getParents().size());
            assertEquals("students", 3, copy.getStudents().size());
            assertEquals("grades", original.getGradeCount(), copy.getGradeCount());
            for (Student s : original.getStudents()) {
                Student c = copy.findStudent(s.getId());
                assertTrue("student " + s.getId() + " exists after reading", c != null);
                assertEquals("name of student " + s.getId(), s.getName(), c.getName());
                assertEquals("age of student " + s.getId(), s.getAge(), c.getAge());
                assertEquals("gender of student " + s.getId(), s.getGender(), c.getGender());
                assertNear("average of student " + s.getId(), s.getAverageGrade(), c.getAverageGrade());
                assertEquals("bonus of student " + s.getId(), s.getBonus(), c.getBonus());
                assertEquals("parent of student " + s.getId(), s.getParent().getId(), c.getParent().getId());
            }
            for (Parent p : original.getParents()) {
                Parent c = copy.findParent(p.getId());
                assertTrue("parent " + p.getId() + " exists after reading", c != null);
                assertEquals("name of parent " + p.getId(), p.getName(), c.getName());
                assertEquals("status of parent " + p.getId(), p.getMood(), c.getMood());
                assertEquals("bonuses of parent " + p.getId(), p.getTotalBonusPaid(), c.getTotalBonusPaid());
                assertEquals("children of parent " + p.getId(), p.getChildren().size(), c.getChildren().size());
            }
            assertEquals("special characters in a name", "Alice; \"A\" \\ Test", copy.findStudent(1).getName());
            assertEquals("line break in a name", "Parent A\nsecond line", copy.findParent(1).getName());
        } finally {
            f.delete();
        }
    }

    private void databaseOperations() throws IOException {
        File f = File.createTempFile("lab4-crud", ".db");
        try {
            final StudentDatabase db = new StudentDatabase(f, new SemesterModel(12));
            Student s1 = db.put(new Student("Student One", 18, Gender.MALE), new Parent("Parent One", 45, Gender.FEMALE));
            Student s2 = db.put(new Student("Student Two", 19, Gender.FEMALE), new Parent("Parent Two", 46, Gender.MALE));
            assertEquals("id of the first student", 1, s1.getId());
            assertEquals("id of the second student", 2, s2.getId());
            assertEquals("size of the list after put", 2, db.get().size());
            assertTrue("get(id) returns the stored object", db.get(2) == s2);
            assertTrue("get(unknown id) returns null", db.get(99) == null);
            assertTrue("the list is marked as changed after put", db.isDirty());

            db.change(2, "Student Deux", Integer.valueOf(21), null, null, Integer.valueOf(50), null);
            assertEquals("new name", "Student Deux", db.get(2).getName());
            assertEquals("new age", 21, db.get(2).getAge());
            assertEquals("gender is kept", Gender.FEMALE, db.get(2).getGender());
            assertEquals("parent name is kept", "Parent Two", db.get(2).getParent().getName());
            assertEquals("new parent age", 50, db.get(2).getParent().getAge());
            expectThrows(IllegalArgumentException.class, "change with a wrong age",
                    () -> db.change(1, "Must not be applied", Integer.valueOf(-5), null, null, null, null));
            assertEquals("nothing is changed by a failed change", "Student One", db.get(1).getName());
            expectThrows(IllegalArgumentException.class, "change of an unknown id",
                    () -> db.change(77, "X", null, null, null, null, null));

            Student removed = db.del(1);
            assertTrue("del returns the removed student", removed == s1);
            assertTrue("the removed student is gone", db.get(1) == null);
            assertEquals("the parent without children is removed", 1, db.getModel().getParents().size());
            assertTrue("del of an unknown id returns null", db.del(1) == null);

            Student s3 = db.put(new Student("Student Three", 20, Gender.MALE), new Parent("Parent Three", 47, Gender.MALE));
            assertEquals("ids are not reused", 3, s3.getId());

            final Parent existing = db.get(2).getParent();
            db.put(new Student("Student Four", 19, Gender.MALE), existing);
            assertEquals("children of an existing parent", 2, existing.getChildren().size());
            assertEquals("no extra parent is created", 2, db.getModel().getParents().size());
            existing.reviewResults();
            expectThrows(IllegalStateException.class, "put under a parent who has already paid the bonuses",
                    () -> db.put(new Student("Late", 20, Gender.MALE), existing));
            assertEquals("a refused put changes nothing", 3, db.get().size());

            db.write();
            assertTrue("the list is not marked as changed after write", !db.isDirty());
            StudentDatabase other = new StudentDatabase(f, new SemesterModel(12));
            other.read();
            assertEquals("students after read", 3, other.get().size());
            assertEquals("name after read", "Student Deux", other.get(2).getName());
            assertEquals("parent age after read", 50, other.get(2).getParent().getAge());
            assertTrue("deleted student stays deleted", other.get(1) == null);
        } finally {
            f.delete();
        }
    }

    private void damagedFiles() throws IOException {
        File f = File.createTempFile("lab4-damaged", ".db");
        try {
            expectFormatError(f, "empty file", "");
            expectFormatError(f, "missing FORMAT record", "SEMESTER;12\n");
            expectFormatError(f, "text instead of a number", "FORMAT;1\nSEMESTER;twelve\n");
            expectFormatError(f, "unknown record type", "FORMAT;1\nSEMESTER;12\nBOGUS;1\n");
            expectFormatError(f, "unknown parent", "FORMAT;1\nSEMESTER;12\nSTUDENT;1;Bob;20;male;5\n");
            expectFormatError(f, "wrong number of fields", "FORMAT;1\nSEMESTER;12\nSTUDENT;1;Bob;20;male\n");
            expectFormatError(f, "escape at the end of the line", "FORMAT;1\nSEMESTER;12\nTEACHER;1;Bad\\");
            StringBuilder tooMany = new StringBuilder("FORMAT;1\nSEMESTER;12\nTEACHER;1;T;40;male;Math\n"
                    + "PARENT;1;P;40;male;false\nSTUDENT;1;S;20;male;1\n");
            for (int week = 1; week <= Student.MAX_GRADES_PER_SUBJECT + 1; week++) {
                tooMany.append("GRADE;1;1;").append(week).append(";4\n");
            }
            expectFormatError(f, "11 grades in one subject", tooMany.toString());
        } finally {
            f.delete();
        }
        final File missing = new File(f.getPath() + ".missing");
        expectThrows(FileNotFoundException.class, "missing file", () -> ModelFileStorage.read(missing));
    }

    private void settingsParsing() throws IOException {
        final File f = File.createTempFile("lab4-settings", ".properties");
        try {
            writeText(f, "login=root_user\npassword=secret\ngroup=ROOT\ndebug=true\nautotests=False\n"
                    + "database=my.db\nlog=my.log\n");
            Settings s = SettingsLoader.load(f);
            assertEquals("login", "root_user", s.getLogin());
            assertEquals("password", "secret", s.getPassword());
            assertEquals("group", UserGroup.ROOT, s.getGroup());
            assertTrue("debug flag", s.isDebug());
            assertTrue("autotests flag", !s.isAutotests());
            assertEquals("database file", "my.db", s.getDatabaseFile().getPath());
            assertEquals("log file", "my.log", s.getLogFile().getPath());

            writeText(f, "login=u\npassword=p\ngroup=user\ndebug=false\nautotests=true\n");
            s = SettingsLoader.load(f);
            assertTrue("user group is not root", !s.isRoot());
            assertEquals("default database file", SettingsLoader.DEFAULT_DATABASE, s.getDatabaseFile().getPath());
            assertEquals("default log file", SettingsLoader.DEFAULT_LOG, s.getLogFile().getPath());

            writeText(f, "login=u\npassword=p\ngroup=admin\ndebug=false\nautotests=true\n");
            expectThrows(SettingsException.class, "unknown group", () -> SettingsLoader.load(f));
            writeText(f, "login=u\npassword=p\ngroup=user\ndebug=maybe\nautotests=true\n");
            expectThrows(SettingsException.class, "wrong debug value", () -> SettingsLoader.load(f));
            writeText(f, "password=p\ngroup=user\ndebug=false\nautotests=true\n");
            expectThrows(SettingsException.class, "missing login", () -> SettingsLoader.load(f));
        } finally {
            f.delete();
        }
    }

    private void loggerBehaviour() throws IOException {
        File dir = Files.createTempDirectory("lab4-log").toFile();
        File f = new File(dir, "test.log");
        try {
            AppLogger off = new AppLogger(f, false);
            off.info("ignored");
            off.debug("ignored");
            off.error("ignored");
            assertTrue("a disabled log writes nothing", !f.exists());
            off.test("autotest record");
            assertEquals("autotest records are written even when the log is disabled", 1, off.tail(100).size());

            AppLogger on = new AppLogger(f, true); // a new logger on the same file must append
            on.info("first");
            on.error("second", new IllegalStateException("boom"));
            on.info("line one\nline two");
            List<String> lines = on.tail(100);
            assertEquals("records are appended, not overwritten", 4, lines.size());
            assertTrue("the old record is kept", lines.get(0).contains("autotest record"));
            String pattern = "\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}\\.\\d{3} \\[(INFO |DEBUG|ERROR|TEST )\\] .*";
            for (String line : lines) {
                assertTrue("record has a time stamp and a level: " + line, line.matches(pattern));
            }
            on.setEnabled(false);
            on.info("not written");
            assertEquals("nothing is written after the log is disabled", 4, on.tail(100).size());
        } finally {
            f.delete();
            dir.delete();
        }
    }

    // ------------------------------------------------------------------ helpers

    private static void writeText(File file, String text) throws IOException {
        Files.write(file.toPath(), text.getBytes(StandardCharsets.UTF_8));
    }

    private static void expectFormatError(File file, String what, String content) throws IOException {
        writeText(file, content);
        try {
            ModelFileStorage.read(file);
        } catch (DatabaseFormatException e) {
            return;
        }
        throw new AssertionError(what + ": the file was accepted but must be rejected");
    }

    private static void expectThrows(Class<? extends Throwable> type, String what, Check action) {
        try {
            action.run();
        } catch (Throwable t) {
            if (type.isInstance(t)) {
                return;
            }
            throw new AssertionError(what + ": expected " + type.getSimpleName() + " but got " + t);
        }
        throw new AssertionError(what + ": expected " + type.getSimpleName() + " but nothing was thrown");
    }

    private static void assertTrue(String what, boolean condition) {
        if (!condition) {
            throw new AssertionError(what);
        }
    }

    private static void assertEquals(String what, Object expected, Object actual) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError(what + ": expected <" + expected + "> but was <" + actual + ">");
        }
    }

    private static void assertNear(String what, double expected, double actual) {
        if (Math.abs(expected - actual) > 1e-9) {
            throw new AssertionError(what + ": expected <" + expected + "> but was <" + actual + ">");
        }
    }
}
