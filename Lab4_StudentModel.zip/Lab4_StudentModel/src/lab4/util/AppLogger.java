package lab4.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.List;

/**
 * Text log. Every record is one line: {@code yyyy-MM-dd HH:mm:ss.SSS [LEVEL] message}.
 * The file is appended, never overwritten.
 *
 * <p>The log is written only while it is enabled (debug mode); the records of the autotests
 * ({@link #test(String)}) are written always, because the task requires the results of the tests
 * in the log independently of the debug mode.
 */
public class AppLogger {

    /** Level of a record. */
    public enum Level { INFO, DEBUG, ERROR, TEST }

    private final File file;
    private final SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    private boolean enabled;
    private boolean failureReported;

    public AppLogger(File file, boolean enabled) {
        if (file == null) {
            throw new IllegalArgumentException("Log file must not be null");
        }
        this.file = file;
        this.enabled = enabled;
    }

    public File getFile() {
        return file;
    }

    public synchronized boolean isEnabled() {
        return enabled;
    }

    public synchronized void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public void info(String message) {
        write(Level.INFO, message, false);
    }

    public void debug(String message) {
        write(Level.DEBUG, message, false);
    }

    public void error(String message) {
        write(Level.ERROR, message, false);
    }

    public void error(String message, Throwable cause) {
        write(Level.ERROR, message + ": " + cause, false);
    }

    /** A record of the autotests; written even when the log is disabled. */
    public void test(String message) {
        write(Level.TEST, message, true);
    }

    /** Appends one record to the file. A failure to write never stops the program. */
    public synchronized void write(Level level, String message, boolean force) {
        if (!enabled && !force) {
            return;
        }
        String text = message == null ? "" : message.replaceAll("\\r\\n|\\r|\\n", " | ");
        String line = format.format(new Date()) + " [" + String.format("%-5s", level) + "] " + text;
        File dir = file.getAbsoluteFile().getParentFile();
        if (dir != null && !dir.isDirectory()) {
            dir.mkdirs();
        }
        try (BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(file, true), StandardCharsets.UTF_8))) {
            out.write(line);
            out.newLine();
        } catch (IOException e) {
            if (!failureReported) {
                failureReported = true;
                System.out.println("[WARNING] Cannot write the log file " + file.getPath() + ": " + e.getMessage());
            }
        }
    }

    /** The last {@code count} records of the log file (empty if the file does not exist). */
    public synchronized List<String> tail(int count) throws IOException {
        List<String> result = new ArrayList<String>();
        if (!file.isFile()) {
            return result;
        }
        Deque<String> last = new ArrayDeque<String>();
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = in.readLine()) != null) {
                last.addLast(line);
                if (last.size() > count) {
                    last.removeFirst();
                }
            }
        }
        result.addAll(last);
        return result;
    }
}
