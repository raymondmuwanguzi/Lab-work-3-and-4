package lab4;

import java.io.File;
import java.io.IOException;

import lab4.config.Settings;
import lab4.config.SettingsLoader;
import lab4.controller.MainController;
import lab4.controller.SemesterController;
import lab4.controller.StudentController;
import lab4.model.SemesterModel;
import lab4.model.StudentDatabase;
import lab4.util.AppLogger;
import lab4.view.ConsoleView;

/**
 * Entry point of laboratory work No. 4: the model of a student's semester (Lab 2) with the
 * "database" file, the settings file, the log and the autotests.
 *
 * <p>Optional argument: path of the settings file (default {@code settings.properties} in the
 * working directory).
 */
public class Main {

    public static final String DEFAULT_SETTINGS_FILE = "settings.properties";
    private static final long SEED = 2026L;

    public static void main(String[] args) {
        File settingsFile = new File(args.length > 0 ? args[0] : DEFAULT_SETTINGS_FILE);

        // 1. the settings are read before anything else
        Settings settings;
        try {
            settings = SettingsLoader.load(settingsFile);
        } catch (IOException e) {
            System.out.println("[ERROR] Cannot start the program: " + e.getMessage());
            // without settings the debug mode is unknown: the error goes to the default log
            new AppLogger(new File(SettingsLoader.DEFAULT_LOG), true).error("Cannot start the program", e);
            System.exit(1);
            return;
        }

        // 2. model + view + controllers
        AppLogger logger = new AppLogger(settings.getLogFile(), settings.isDebug());
        StudentDatabase database = new StudentDatabase(settings.getDatabaseFile(),
                new SemesterModel(SemesterController.WEEKS));
        ConsoleView view = new ConsoleView();
        SemesterController semesterController = new SemesterController(database, view, logger, SEED);
        StudentController studentController = new StudentController(database, view, logger);
        MainController controller = new MainController(settings, settingsFile, logger, database, view,
                semesterController, studentController);

        // 3. login, autotests, main menu
        int exitCode = controller.run();
        if (exitCode != MainController.EXIT_OK) {
            System.exit(exitCode);
        }
    }
}
