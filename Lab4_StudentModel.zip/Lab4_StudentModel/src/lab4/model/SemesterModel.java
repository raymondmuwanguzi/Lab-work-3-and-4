package lab4.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** The whole model of one semester: a group of students, their parents and teachers. */
public class SemesterModel {

    private final int weeks;
    private final List<Student> students = new ArrayList<Student>();
    private final List<Parent> parents = new ArrayList<Parent>();
    private final List<Teacher> teachers = new ArrayList<Teacher>();

    private int nextStudentId = 1;
    private int nextParentId = 1;
    private int nextTeacherId = 1;

    public SemesterModel(int weeks) {
        if (weeks < Student.MAX_GRADES_PER_SUBJECT) {
            throw new IllegalArgumentException(
                    "A semester must have at least " + Student.MAX_GRADES_PER_SUBJECT + " weeks");
        }
        this.weeks = weeks;
    }

    public int getWeeks() {
        return weeks;
    }

    /** Adds a student; a student without an id gets the next free one. */
    public void addStudent(Student student) {
        if (student == null) {
            throw new IllegalArgumentException("Student must not be null");
        }
        if (student.getId() < 0) {
            throw new IllegalArgumentException("Student id must not be negative: " + student.getId());
        }
        if (student.getId() != 0 && findStudent(student.getId()) != null) {
            throw new IllegalArgumentException("Duplicate student id: " + student.getId());
        }
        if (student.getId() == 0) {
            student.setId(nextStudentId);
        }
        nextStudentId = Math.max(nextStudentId, student.getId() + 1);
        students.add(student);
    }

    /** Adds a parent; a parent without an id gets the next free one. */
    public void addParent(Parent parent) {
        if (parent == null) {
            throw new IllegalArgumentException("Parent must not be null");
        }
        if (parent.getId() < 0) {
            throw new IllegalArgumentException("Parent id must not be negative: " + parent.getId());
        }
        if (parent.getId() != 0 && findParent(parent.getId()) != null) {
            throw new IllegalArgumentException("Duplicate parent id: " + parent.getId());
        }
        if (parent.getId() == 0) {
            parent.setId(nextParentId);
        }
        nextParentId = Math.max(nextParentId, parent.getId() + 1);
        parents.add(parent);
    }

    /** Adds a teacher; a teacher without an id gets the next free one. */
    public void addTeacher(Teacher teacher) {
        if (teacher == null) {
            throw new IllegalArgumentException("Teacher must not be null");
        }
        if (teacher.getId() < 0) {
            throw new IllegalArgumentException("Teacher id must not be negative: " + teacher.getId());
        }
        if (teacher.getId() != 0 && findTeacher(teacher.getId()) != null) {
            throw new IllegalArgumentException("Duplicate teacher id: " + teacher.getId());
        }
        if (teacher.getId() == 0) {
            teacher.setId(nextTeacherId);
        }
        nextTeacherId = Math.max(nextTeacherId, teacher.getId() + 1);
        teachers.add(teacher);
    }

    /**
     * Removes the student from the model together with his grades. The student is detached from
     * the parent; a parent left without children is removed as well.
     *
     * @return true if the student was in the model
     */
    public boolean removeStudent(Student student) {
        if (student == null || !students.remove(student)) {
            return false;
        }
        Parent parent = student.getParent();
        if (parent != null) {
            parent.removeChild(student);
            if (parent.getChildren().isEmpty()) {
                parents.remove(parent);
            }
        }
        return true;
    }

    public Student findStudent(int id) {
        for (Student s : students) {
            if (s.getId() == id) {
                return s;
            }
        }
        return null;
    }

    public Parent findParent(int id) {
        for (Parent p : parents) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null;
    }

    public Teacher findTeacher(int id) {
        for (Teacher t : teachers) {
            if (t.getId() == id) {
                return t;
            }
        }
        return null;
    }

    public List<Student> getStudents() {
        return Collections.unmodifiableList(students);
    }

    public List<Parent> getParents() {
        return Collections.unmodifiableList(parents);
    }

    public List<Teacher> getTeachers() {
        return Collections.unmodifiableList(teachers);
    }

    /** Subjects taught in the semester, in the order of the teachers. */
    public List<Subject> getSubjects() {
        Set<Subject> subjects = new LinkedHashSet<Subject>();
        for (Teacher t : teachers) {
            subjects.add(t.getSubject());
        }
        return new ArrayList<Subject>(subjects);
    }

    /** Total number of grades of all students. */
    public int getGradeCount() {
        int total = 0;
        for (Student s : students) {
            total += s.getTotalGradeCount();
        }
        return total;
    }

    /** End of the semester: every parent reviews the results and pays the bonuses. */
    public void settleBonuses() {
        for (Parent p : parents) {
            p.reviewResults();
        }
    }
}
