package lab4.model;

import java.util.Locale;

/** Gender of a person. */
public enum Gender {
    MALE("male"),
    FEMALE("female");

    private final String title;

    Gender(String title) {
        this.title = title;
    }

    /** Parses "male"/"m" or "female"/"f" (case-insensitive). */
    public static Gender parse(String text) {
        if (text != null) {
            String t = text.trim().toLowerCase(Locale.ROOT);
            if (t.equals("male") || t.equals("m")) {
                return MALE;
            }
            if (t.equals("female") || t.equals("f")) {
                return FEMALE;
            }
        }
        throw new IllegalArgumentException("Unknown gender: '" + text + "' (use male/m or female/f)");
    }

    @Override
    public String toString() {
        return title;
    }
}
