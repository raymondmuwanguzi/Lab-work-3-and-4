package lab4.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A parent of one or several students. Pays bonuses depending on the students' results. */
public class Parent extends Person {

    private final List<Student> children = new ArrayList<Student>();
    private ParentMood mood = ParentMood.NEUTRAL;
    private int totalBonusPaid; // in thousands
    private boolean reviewed;

    public Parent(String name, int age, Gender gender) {
        super(name, age, gender);
    }

    public void addChild(Student student) {
        if (student == null) {
            throw new IllegalArgumentException("Student must not be null");
        }
        if (student.getParent() != null) {
            throw new IllegalStateException(student.getName() + " already has a parent");
        }
        children.add(student);
        student.setParent(this);
    }

    /**
     * Detaches the student from this parent (the student was removed from the model).
     * If the results were already reviewed, the bonus paid to this student is taken back from
     * the total and the status is recalculated for the remaining children.
     *
     * @return true if the student was a child of this parent
     */
    public boolean removeChild(Student student) {
        if (student == null || !children.remove(student)) {
            return false;
        }
        student.setParent(null);
        if (reviewed) {
            totalBonusPaid = Math.max(0, totalBonusPaid - student.getBonus());
            if (children.isEmpty()) {
                mood = ParentMood.NEUTRAL;
            } else {
                double sum = 0.0;
                for (Student child : children) {
                    sum += child.getAverageGrade();
                }
                mood = ParentMood.forAverage(sum / children.size());
            }
        }
        return true;
    }

    public List<Student> getChildren() {
        return Collections.unmodifiableList(children);
    }

    public ParentMood getMood() {
        return mood;
    }

    public int getTotalBonusPaid() {
        return totalBonusPaid;
    }

    /** True once the parent has reviewed the session results and paid the bonuses. */
    public boolean isReviewed() {
        return reviewed;
    }

    /**
     * Reviews the session results: every child gets the bonus corresponding to his own
     * average grade; the parent's status is determined by the mean of the children's averages.
     * Bonuses are paid only once.
     */
    public void reviewResults() {
        if (reviewed || children.isEmpty()) {
            return;
        }
        double sumOfAverages = 0.0;
        for (Student child : children) {
            double average = child.getAverageGrade();
            int bonus = ParentMood.forAverage(average).getBonus();
            child.receiveBonus(bonus);
            totalBonusPaid += bonus;
            sumOfAverages += average;
        }
        mood = ParentMood.forAverage(sumOfAverages / children.size());
        reviewed = true;
    }

    @Override
    public String toString() {
        StringBuilder names = new StringBuilder();
        for (Student child : children) {
            if (names.length() > 0) {
                names.append(", ");
            }
            names.append(child.getName());
        }
        return "Parent: " + super.toString() + ", status: " + mood + ", student(s): "
                + (names.length() == 0 ? "-" : names) + ", bonuses paid: " + totalBonusPaid
                + " thousand";
    }
}
