package lab4.model;

import java.io.IOException;

/** The "database" file exists but its content is not valid. */
public class DatabaseFormatException extends IOException {

    private static final long serialVersionUID = 1L;

    public DatabaseFormatException(int lineNumber, String message) {
        super("line " + lineNumber + ": " + message);
    }

    public DatabaseFormatException(String message) {
        super(message);
    }
}
