package lab4.model;

/** Base class for every human in the model: id, name, age and gender. */
public abstract class Person {

    /** Unique id inside the entity type; 0 means "not assigned yet". */
    private int id;
    private String name;
    private int age;
    private Gender gender;

    protected Person(String name, int age, Gender gender) {
        this.name = checkName(name);
        this.age = checkAge(age);
        this.gender = checkGender(gender);
    }

    /** Validates a name and returns it trimmed. */
    public static String checkName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name must not be empty");
        }
        return name.trim();
    }

    public static int checkAge(int age) {
        if (age <= 0) {
            throw new IllegalArgumentException("Age must be positive: " + age);
        }
        return age;
    }

    public static Gender checkGender(Gender gender) {
        if (gender == null) {
            throw new IllegalArgumentException("Gender must not be null");
        }
        return gender;
    }

    public int getId() {
        return id;
    }

    /** Package-private: ids are assigned by {@link SemesterModel} or restored from the file. */
    void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = checkName(name);
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = checkAge(age);
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = checkGender(gender);
    }

    /** Common part of the description used by subclasses: name, age, gender. */
    @Override
    public String toString() {
        return name + ", age " + age + ", " + gender;
    }
}
