package lab4.model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads and writes the whole {@link SemesterModel} as a simple text file ("database").
 *
 * <p>The file is UTF-8, one record per line, the fields of a record are separated by ';'.
 * Inside a field the characters '\', ';', line feed and carriage return are escaped as
 * {@code \\}, {@code \;}, {@code \n} and {@code \r}. Empty lines and lines starting with '#' are
 * ignored. Records (in this order):
 * <pre>
 * FORMAT;1
 * SEMESTER;weeks
 * TEACHER;id;name;age;gender;subject
 * PARENT;id;name;age;gender;reviewed
 * STUDENT;id;name;age;gender;parentId        (parentId 0 = no parent)
 * GRADE;studentId;teacherId;week;value
 * </pre>
 * Every entity has an id that is unique inside its record type; grades refer to the student and
 * the teacher by these ids. The bonuses and the statuses of the parents are not stored: they are
 * recalculated after reading for the parents with {@code reviewed = true}.
 */
public final class ModelFileStorage {

    public static final int FORMAT_VERSION = 1;

    private ModelFileStorage() {
    }

    // ------------------------------------------------------------------ writing

    /** Writes the model to the file (the old content is replaced only when writing succeeded). */
    public static void write(SemesterModel model, File file) throws IOException {
        File target = file.getAbsoluteFile();
        File dir = target.getParentFile();
        if (dir != null && !dir.isDirectory() && !dir.mkdirs()) {
            throw new IOException("Cannot create directory: " + dir);
        }
        File temp = new File(dir, target.getName() + ".tmp");
        try (BufferedWriter out = new BufferedWriter(
                new OutputStreamWriter(new FileOutputStream(temp), StandardCharsets.UTF_8))) {
            writeModel(model, out);
        } catch (IOException | RuntimeException e) {
            temp.delete();
            throw e;
        }
        Files.move(temp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
    }

    private static void writeModel(SemesterModel model, BufferedWriter out) throws IOException {
        out.write("# Student database of laboratory work No. 4 (UTF-8, fields are separated by ';')");
        out.newLine();
        out.write("# Escapes inside a field: \\\\ for '\\', \\; for ';', \\n and \\r for line breaks");
        out.newLine();
        record(out, "FORMAT", FORMAT_VERSION);
        record(out, "SEMESTER", model.getWeeks());
        for (Teacher t : model.getTeachers()) {
            record(out, "TEACHER", t.getId(), t.getName(), t.getAge(), t.getGender(), t.getSubject().getTitle());
        }
        for (Parent p : model.getParents()) {
            record(out, "PARENT", p.getId(), p.getName(), p.getAge(), p.getGender(), p.isReviewed());
        }
        for (Student s : model.getStudents()) {
            int parentId = s.getParent() == null ? 0 : s.getParent().getId();
            record(out, "STUDENT", s.getId(), s.getName(), s.getAge(), s.getGender(), parentId);
        }
        for (Student s : model.getStudents()) {
            for (Grade g : s.getAllGrades()) {
                if (!model.getTeachers().contains(g.getTeacher())) {
                    throw new IOException("A grade of " + s.getName() + " refers to teacher "
                            + g.getTeacher().getName() + " who is not in the model");
                }
                record(out, "GRADE", s.getId(), g.getTeacher().getId(), g.getWeek(), g.getValue());
            }
        }
    }

    private static void record(BufferedWriter out, String type, Object... fields) throws IOException {
        StringBuilder line = new StringBuilder(type);
        for (Object field : fields) {
            line.append(';').append(escape(String.valueOf(field)));
        }
        out.write(line.toString());
        out.newLine();
    }

    static String escape(String text) {
        StringBuilder sb = new StringBuilder(text.length() + 8);
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            switch (c) {
                case '\\':
                    sb.append("\\\\");
                    break;
                case ';':
                    sb.append("\\;");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                default:
                    sb.append(c);
                    break;
            }
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ reading

    /**
     * Reads a model from the file.
     *
     * @throws FileNotFoundException   if the file does not exist
     * @throws DatabaseFormatException if the content is invalid (the message contains the line number)
     */
    public static SemesterModel read(File file) throws IOException {
        if (!file.isFile()) {
            throw new FileNotFoundException("Database file not found: " + file.getPath());
        }
        try (BufferedReader in = new BufferedReader(
                new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            return readModel(in);
        }
    }

    private static SemesterModel readModel(BufferedReader in) throws IOException {
        SemesterModel model = null;
        boolean formatSeen = false;
        List<Parent> reviewedParents = new ArrayList<Parent>();
        int lineNo = 0;
        String line;
        while ((line = in.readLine()) != null) {
            lineNo++;
            if (lineNo == 1 && line.startsWith("\uFEFF")) {
                line = line.substring(1); // byte order mark written by some editors
            }
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                continue;
            }
            List<String> f = split(line, lineNo);
            String type = f.get(0).trim();
            try {
                if (type.equals("FORMAT")) {
                    requireFields(f, 2, lineNo);
                    int version = parseInt(f.get(1), "format version", lineNo);
                    if (version != FORMAT_VERSION) {
                        throw new DatabaseFormatException(lineNo, "unsupported format version " + version);
                    }
                    formatSeen = true;
                    continue;
                }
                if (!formatSeen) {
                    throw new DatabaseFormatException(lineNo, "the FORMAT record must be the first record");
                }
                if (type.equals("SEMESTER")) {
                    if (model != null) {
                        throw new DatabaseFormatException(lineNo, "duplicate SEMESTER record");
                    }
                    requireFields(f, 2, lineNo);
                    model = new SemesterModel(parseInt(f.get(1), "weeks", lineNo));
                    continue;
                }
                if (model == null) {
                    throw new DatabaseFormatException(lineNo, "the SEMESTER record must precede " + type);
                }
                if (type.equals("TEACHER")) {
                    requireFields(f, 6, lineNo);
                    Teacher t = new Teacher(f.get(2), parseInt(f.get(3), "age", lineNo),
                            Gender.parse(f.get(4)), new Subject(f.get(5)));
                    t.setId(parseId(f.get(1), lineNo));
                    model.addTeacher(t);
                } else if (type.equals("PARENT")) {
                    requireFields(f, 6, lineNo);
                    Parent p = new Parent(f.get(2), parseInt(f.get(3), "age", lineNo), Gender.parse(f.get(4)));
                    p.setId(parseId(f.get(1), lineNo));
                    model.addParent(p);
                    if (parseBoolean(f.get(5), "reviewed", lineNo)) {
                        reviewedParents.add(p);
                    }
                } else if (type.equals("STUDENT")) {
                    requireFields(f, 6, lineNo);
                    Student s = new Student(f.get(2), parseInt(f.get(3), "age", lineNo), Gender.parse(f.get(4)));
                    s.setId(parseId(f.get(1), lineNo));
                    int parentId = parseInt(f.get(5), "parent id", lineNo);
                    Parent parent = null;
                    if (parentId != 0) {
                        parent = model.findParent(parentId);
                        if (parent == null) {
                            throw new DatabaseFormatException(lineNo, "unknown parent id " + parentId);
                        }
                    }
                    model.addStudent(s);
                    if (parent != null) {
                        parent.addChild(s);
                    }
                } else if (type.equals("GRADE")) {
                    requireFields(f, 5, lineNo);
                    int studentId = parseInt(f.get(1), "student id", lineNo);
                    int teacherId = parseInt(f.get(2), "teacher id", lineNo);
                    int week = parseInt(f.get(3), "week", lineNo);
                    int value = parseInt(f.get(4), "grade value", lineNo);
                    Student s = model.findStudent(studentId);
                    if (s == null) {
                        throw new DatabaseFormatException(lineNo, "unknown student id " + studentId);
                    }
                    Teacher t = model.findTeacher(teacherId);
                    if (t == null) {
                        throw new DatabaseFormatException(lineNo, "unknown teacher id " + teacherId);
                    }
                    if (week > model.getWeeks()) {
                        throw new DatabaseFormatException(lineNo,
                                "week " + week + " is outside the semester (" + model.getWeeks() + " weeks)");
                    }
                    s.addGrade(new Grade(value, week, t.getSubject(), t));
                } else {
                    throw new DatabaseFormatException(lineNo, "unknown record type '" + type + "'");
                }
            } catch (IllegalArgumentException | IllegalStateException e) {
                throw new DatabaseFormatException(lineNo, e.getMessage());
            }
        }
        if (!formatSeen || model == null) {
            throw new DatabaseFormatException("the file contains no FORMAT/SEMESTER records");
        }
        for (Parent p : reviewedParents) {
            p.reviewResults(); // restores the bonuses and the status
        }
        return model;
    }

    private static List<String> split(String line, int lineNo) throws DatabaseFormatException {
        List<String> fields = new ArrayList<String>();
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '\\') {
                if (i + 1 >= line.length()) {
                    throw new DatabaseFormatException(lineNo, "escape character at the end of the line");
                }
                char next = line.charAt(++i);
                switch (next) {
                    case '\\':
                        current.append('\\');
                        break;
                    case ';':
                        current.append(';');
                        break;
                    case 'n':
                        current.append('\n');
                        break;
                    case 'r':
                        current.append('\r');
                        break;
                    default:
                        throw new DatabaseFormatException(lineNo, "unknown escape sequence \\" + next);
                }
            } else if (c == ';') {
                fields.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        fields.add(current.toString());
        return fields;
    }

    private static void requireFields(List<String> fields, int count, int lineNo) throws DatabaseFormatException {
        if (fields.size() != count) {
            throw new DatabaseFormatException(lineNo, fields.get(0).trim() + " record must have "
                    + (count - 1) + " fields but has " + (fields.size() - 1));
        }
    }

    private static int parseInt(String text, String what, int lineNo) throws DatabaseFormatException {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException e) {
            throw new DatabaseFormatException(lineNo, what + " is not an integer: '" + text + "'");
        }
    }

    private static int parseId(String text, int lineNo) throws DatabaseFormatException {
        int id = parseInt(text, "id", lineNo);
        if (id <= 0) {
            throw new DatabaseFormatException(lineNo, "id must be positive: " + id);
        }
        return id;
    }

    private static boolean parseBoolean(String text, String what, int lineNo) throws DatabaseFormatException {
        String t = text.trim();
        if (t.equalsIgnoreCase("true")) {
            return true;
        }
        if (t.equalsIgnoreCase("false")) {
            return false;
        }
        throw new DatabaseFormatException(lineNo, what + " must be true or false: '" + text + "'");
    }
}
