package lab4.model;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * The "database" of the program: the list of students (with their parents and grades) kept in the
 * memory plus the text file on the disk. Provides the four basic operations over the list
 * ({@link #get()}, {@link #put}, {@link #change}, {@link #del}) and the operations
 * {@link #read()} / {@link #write()} that synchronise the list with the file.
 */
public class StudentDatabase {

    private final File file;
    private SemesterModel model;
    private boolean dirty;

    public StudentDatabase(File file, SemesterModel model) {
        if (file == null || model == null) {
            throw new IllegalArgumentException("File and model must not be null");
        }
        this.file = file;
        this.model = model;
    }

    public File getFile() {
        return file;
    }

    public SemesterModel getModel() {
        return model;
    }

    /** Replaces the whole model (e.g. by newly generated data); the changes are not saved yet. */
    public void setModel(SemesterModel model) {
        if (model == null) {
            throw new IllegalArgumentException("Model must not be null");
        }
        this.model = model;
        dirty = true;
    }

    /** True if the list in the memory differs from the file (there are unsaved changes). */
    public boolean isDirty() {
        return dirty;
    }

    // ------------------------------------------------------------- list operations

    /** All students of the list (read-only view). */
    public List<Student> get() {
        return model.getStudents();
    }

    /** The student with the given id or null. */
    public Student get(int id) {
        return model.findStudent(id);
    }

    /**
     * Adds a new student to the list. {@code parent} is either a parent that is already in the
     * list (the student becomes one more child of him) or a new parent that is added together
     * with the student. The student gets a unique id.
     *
     * @throws IllegalStateException if the parent has already paid the bonuses (the semester is closed
     *                               for him) or the student already has a parent
     */
    public Student put(Student student, Parent parent) {
        if (student == null || parent == null) {
            throw new IllegalArgumentException("Student and parent must not be null");
        }
        if (parent.isReviewed()) {
            throw new IllegalStateException(parent.getName()
                    + " has already reviewed the results; add the student under a new parent");
        }
        parent.addChild(student);
        if (!model.getParents().contains(parent)) {
            model.addParent(parent);
        }
        model.addStudent(student);
        dirty = true;
        return student;
    }

    /**
     * Changes the data of the student and of his parent. A {@code null} argument means "keep the
     * current value". All new values are validated before anything is changed.
     *
     * @throws IllegalArgumentException if there is no such student or a value is invalid
     */
    public Student change(int id, String name, Integer age, Gender gender,
            String parentName, Integer parentAge, Gender parentGender) {
        Student student = model.findStudent(id);
        if (student == null) {
            throw new IllegalArgumentException("There is no student with id " + id);
        }
        Parent parent = student.getParent();
        boolean parentChanges = parentName != null || parentAge != null || parentGender != null;
        if (parentChanges && parent == null) {
            throw new IllegalArgumentException("The student has no parent to change");
        }
        // validate first, apply afterwards: nothing is changed if any value is wrong
        String newName = name == null ? null : Person.checkName(name);
        Integer newAge = age == null ? null : Integer.valueOf(Person.checkAge(age.intValue()));
        String newParentName = parentName == null ? null : Person.checkName(parentName);
        Integer newParentAge = parentAge == null ? null : Integer.valueOf(Person.checkAge(parentAge.intValue()));

        if (newName != null) {
            student.setName(newName);
        }
        if (newAge != null) {
            student.setAge(newAge.intValue());
        }
        if (gender != null) {
            student.setGender(gender);
        }
        if (newParentName != null) {
            parent.setName(newParentName);
        }
        if (newParentAge != null) {
            parent.setAge(newParentAge.intValue());
        }
        if (parentGender != null) {
            parent.setGender(parentGender);
        }
        if (newName != null || newAge != null || gender != null || parentChanges) {
            dirty = true;
        }
        return student;
    }

    /**
     * Deletes the student (with his grades) from the list. A parent left without children is
     * deleted too.
     *
     * @return the deleted student or null if there is no student with this id
     */
    public Student del(int id) {
        Student student = model.findStudent(id);
        if (student == null) {
            return null;
        }
        model.removeStudent(student);
        dirty = true;
        return student;
    }

    // ------------------------------------------------------------- file operations

    /** Reads the list from the file; the current list is replaced only if reading succeeded. */
    public void read() throws IOException {
        model = ModelFileStorage.read(file);
        dirty = false;
    }

    /** Writes the list to the file. */
    public void write() throws IOException {
        ModelFileStorage.write(model, file);
        dirty = false;
    }
}
