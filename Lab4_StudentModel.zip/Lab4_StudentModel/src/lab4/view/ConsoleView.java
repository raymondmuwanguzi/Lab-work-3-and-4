package lab4.view;

import java.io.BufferedReader;
import java.io.Console;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import lab4.autotest.TestResult;
import lab4.model.Gender;
import lab4.model.Grade;
import lab4.model.Parent;
import lab4.model.SemesterModel;
import lab4.model.Student;
import lab4.model.Subject;
import lab4.model.Teacher;

/**
 * View: prints everything to the console and reads the user's input. Contains no business logic:
 * the input methods only repeat the question until the text has the requested format.
 */
public class ConsoleView {

    private static final String LINE =
            "------------------------------------------------------------------------------------------";

    private final BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

    // ------------------------------------------------------------------ output

    public void showTitle(String title) {
        System.out.println();
        System.out.println("==========================================================================================");
        System.out.println(title);
        System.out.println("==========================================================================================");
    }

    public void showMessage(String message) {
        System.out.println(message);
    }

    public void showError(String message) {
        System.out.println("[ERROR] " + message);
    }

    public void showWelcome(String login) {
        System.out.println();
        System.out.println("Welcome - " + login);
    }

    /** Prints a numbered menu; the last item (number 0) is the exit / back item. */
    public void showMenu(String title, List<String> items, String zeroItem) {
        showTitle(title);
        for (int i = 0; i < items.size(); i++) {
            System.out.printf("%2d. %s%n", i + 1, items.get(i));
        }
        System.out.printf("%2d. %s%n", 0, zeroItem);
    }

    /** Prints a list of lines under a title. */
    public void showLines(String title, List<String> lines) {
        showTitle(title);
        if (lines.isEmpty()) {
            System.out.println("(nothing to show)");
        }
        for (String line : lines) {
            System.out.println(line);
        }
    }

    /** Prints the table of students: id, personal data, parent, grades, average, bonus. */
    public void showStudents(List<Student> students) {
        showTitle("STUDENTS (" + students.size() + ")");
        if (students.isEmpty()) {
            System.out.println("(the list is empty)");
            return;
        }
        System.out.printf("%-4s %-22s %-4s %-7s %-26s %-6s %-7s %-5s%n",
                "ID", "Name", "Age", "Gender", "Parent (id)", "Grades", "Average", "Bonus");
        System.out.println(LINE);
        for (Student s : students) {
            Parent p = s.getParent();
            String parent = p == null ? "-" : shorten(p.getName(), 20) + " (" + p.getId() + ")";
            System.out.println(String.format(Locale.US, "%-4d %-22s %-4d %-7s %-26s %-6d %-7.2f %-5d",
                    s.getId(), shorten(s.getName(), 22), s.getAge(), s.getGender(), parent,
                    s.getTotalGradeCount(), s.getAverageGrade(), s.getBonus()));
        }
    }

    /** Prints the number of objects of every kind in the model. */
    public void showModelSummary(SemesterModel model) {
        System.out.println("Teachers: " + model.getTeachers().size() + ", parents: " + model.getParents().size()
                + ", students: " + model.getStudents().size() + ", grades: " + model.getGradeCount()
                + ", weeks in the semester: " + model.getWeeks());
    }

    /** Prints the results of the autotests and the summary line. */
    public void showTestResults(List<TestResult> results) {
        int failed = 0;
        for (TestResult r : results) {
            if (r.isPassed()) {
                System.out.println("[PASS] " + r.getName());
            } else {
                failed++;
                System.out.println("[FAIL] " + r.getName() + " -> " + r.getDetails());
            }
        }
        System.out.println(LINE);
        System.out.println("Autotests finished: " + (results.size() - failed) + " passed, " + failed + " failed");
    }

    /** Prints the teachers (with their subjects) and the students (with their parents). */
    public void showParticipants(SemesterModel model) {
        showTitle("PARTICIPANTS OF THE MODEL");
        System.out.println("Teachers (" + model.getTeachers().size() + "):");
        for (Teacher t : model.getTeachers()) {
            System.out.println("  " + t);
        }
        System.out.println("Students (" + model.getStudents().size() + "):");
        for (Student s : model.getStudents()) {
            String parent = s.getParent() == null ? "-" : s.getParent().getName();
            System.out.println("  " + s.getName() + ", age " + s.getAge() + ", " + s.getGender()
                    + " (parent: " + parent + ")");
        }
    }

    /** Prints the grades issued during one week. */
    public void showWeek(int week, List<Grade> issued) {
        System.out.printf("Week %2d: %3d grade(s) issued%n", week, issued.size());
    }

    /** Prints the grade journal: all grades of every student, subject by subject. */
    public void showJournal(SemesterModel model) {
        showTitle("GRADE JOURNAL (grade@week)");
        for (Student s : model.getStudents()) {
            System.out.println(s.getName());
            for (Subject subject : model.getSubjects()) {
                StringBuilder sb = new StringBuilder();
                for (Grade g : s.getGrades(subject)) {
                    if (sb.length() > 0) {
                        sb.append(' ');
                    }
                    sb.append(g.getValue()).append('@').append(g.getWeek());
                }
                System.out.printf("   %-18s [%2d] %s%n", subject.getTitle(), s.getGradeCount(subject), sb);
            }
        }
    }

    /** Prints the table of average grades per subject and overall. */
    public void showAverageTable(SemesterModel model) {
        showTitle("AVERAGE GRADES");
        StringBuilder header = new StringBuilder(String.format("%-22s", "Student"));
        for (Subject subject : model.getSubjects()) {
            header.append(String.format(" %-12s", shorten(subject.getTitle(), 12)));
        }
        header.append(String.format(" %-8s", "Overall"));
        System.out.println(header);
        System.out.println(LINE);
        for (Student s : model.getStudents()) {
            StringBuilder row = new StringBuilder(String.format("%-22s", shorten(s.getName(), 22)));
            for (Subject subject : model.getSubjects()) {
                row.append(String.format(Locale.US, " %-12.2f", s.getAverageGrade(subject)));
            }
            row.append(String.format(Locale.US, " %-8.2f", s.getAverageGrade()));
            System.out.println(row);
        }
    }

    /** Prints the final descriptions of everybody using the overridden toString() methods. */
    public void showResults(SemesterModel model) {
        showTitle("RESULTS OF THE SEMESTER");
        System.out.println("Teachers:");
        for (Teacher t : model.getTeachers()) {
            System.out.println("  " + t);
        }
        System.out.println("Students:");
        for (Student s : model.getStudents()) {
            System.out.println("  " + s);
        }
        System.out.println("Parents:");
        for (Parent p : model.getParents()) {
            System.out.println("  " + p);
        }
    }

    /** Prints the total amount of bonuses. */
    public void showTotals(SemesterModel model) {
        int total = 0;
        int gloomy = 0;
        int satisfied = 0;
        int joyful = 0;
        for (Parent p : model.getParents()) {
            total += p.getTotalBonusPaid();
            switch (p.getMood()) {
                case GLOOMY:
                    gloomy++;
                    break;
                case SATISFIED:
                    satisfied++;
                    break;
                case JOYFUL:
                    joyful++;
                    break;
                default:
                    break;
            }
        }
        System.out.println(LINE);
        System.out.println("Parents by status: gloomy = " + gloomy + ", satisfied = " + satisfied
                + ", joyful = " + joyful);
        System.out.println("Total bonuses paid: " + total + " thousand");
    }

    // ------------------------------------------------------------------ input

    /**
     * Prints the prompt and reads a line (trimmed, may be empty).
     *
     * @throws InputClosedException if the input has ended
     */
    public String readLine(String prompt) {
        System.out.print(prompt);
        System.out.flush();
        try {
            String line = in.readLine();
            if (line == null) {
                throw new InputClosedException();
            }
            return line.trim();
        } catch (IOException e) {
            throw new InputClosedException();
        }
    }

    /** Reads a password; the characters are not shown when the program runs in a real terminal. */
    public String readPassword(String prompt) {
        Console console = System.console();
        if (console == null) {
            return readLine(prompt);
        }
        char[] chars = console.readPassword("%s", prompt);
        if (chars == null) {
            throw new InputClosedException();
        }
        String password = new String(chars).trim();
        Arrays.fill(chars, ' ');
        return password;
    }

    /** Reads a non-empty line (asks again while the line is empty). */
    public String readNonEmpty(String prompt) {
        while (true) {
            String line = readLine(prompt);
            if (!line.isEmpty()) {
                return line;
            }
            showMessage("The value must not be empty.");
        }
    }

    /** Reads an integer from min to max (asks again until the input is correct). */
    public int readInt(String prompt, int min, int max) {
        while (true) {
            String line = readLine(prompt);
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) {
                    return value;
                }
            } catch (NumberFormatException e) {
                // handled below: ask again
            }
            showMessage("Please enter an integer from " + min + " to " + max + ".");
        }
    }

    /** Reads an integer from min to max; an empty line gives null ("keep the current value"). */
    public Integer readOptionalInt(String prompt, int min, int max) {
        while (true) {
            String line = readLine(prompt);
            if (line.isEmpty()) {
                return null;
            }
            try {
                int value = Integer.parseInt(line);
                if (value >= min && value <= max) {
                    return Integer.valueOf(value);
                }
            } catch (NumberFormatException e) {
                // handled below: ask again
            }
            showMessage("Please enter an integer from " + min + " to " + max + " or leave the line empty.");
        }
    }

    /** Reads a gender (male/m, female/f); asks again until the input is correct. */
    public Gender readGender(String prompt) {
        while (true) {
            try {
                return Gender.parse(readLine(prompt));
            } catch (IllegalArgumentException e) {
                showMessage("Please enter male (m) or female (f).");
            }
        }
    }

    /** Reads a gender; an empty line gives null ("keep the current value"). */
    public Gender readOptionalGender(String prompt) {
        while (true) {
            String line = readLine(prompt);
            if (line.isEmpty()) {
                return null;
            }
            try {
                return Gender.parse(line);
            } catch (IllegalArgumentException e) {
                showMessage("Please enter male (m), female (f) or leave the line empty.");
            }
        }
    }

    /** Asks a yes/no question. */
    public boolean confirm(String prompt) {
        while (true) {
            String answer = readLine(prompt).toLowerCase(Locale.ROOT);
            if (answer.equals("y") || answer.equals("yes")) {
                return true;
            }
            if (answer.equals("n") || answer.equals("no")) {
                return false;
            }
            showMessage("Please answer y or n.");
        }
    }

    /** Full path of a file for the messages. */
    public static String path(File file) {
        return file.getAbsolutePath();
    }

    private static String shorten(String text, int max) {
        return text.length() <= max ? text : text.substring(0, max);
    }
}
