package lab4.view;

/** The console input ended (Ctrl+D / Ctrl+Z or a closed pipe): the program cannot continue. */
public class InputClosedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public InputClosedException() {
        super("The input stream is closed");
    }
}
