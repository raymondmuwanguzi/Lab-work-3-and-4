package lab2;

import lab2.controller.SemesterController;
import lab2.model.SemesterModel;
import lab2.view.ConsoleView;

/** Entry point for Lab 4, extending the Lab 2 student-semester model. */
public class Main {
    public static void main(String[] args) {
        SemesterModel model = new SemesterModel(SemesterController.WEEKS);
        ConsoleView view = new ConsoleView();
        new SemesterController(model, view, 2026L).run();
    }
}
