package lab2.controller;

import lab2.model.*;

/** Small deterministic checks for model rules, run before the menu when configured. */
public final class AutoTests {
    private AutoTests() { }
    public static boolean run(AppLogger log) {
        int passed = 0, failed = 0;
        try {
            Subject subject = new Subject("Test subject");
            Teacher teacher = new Teacher("Test teacher", 40, Gender.MALE, subject);
            Student student = new Student("Test student", 20, Gender.FEMALE);
            teacher.grade(student, 1, 5);
            check(student.getGradeCount(subject) == 1, "grade is recorded"); passed++;
            check(Math.abs(student.getAverageGrade(subject) - 5.0) < 0.001, "average grade calculated"); passed++;
            boolean duplicateRejected = false;
            try { teacher.grade(student, 1, 4); } catch (IllegalStateException ex) { duplicateRejected = true; }
            check(duplicateRejected, "duplicate grade in same week rejected"); passed++;
            boolean invalidRejected = false;
            try { teacher.grade(student, 2, 6); } catch (IllegalArgumentException ex) { invalidRejected = true; }
            check(invalidRejected, "invalid mark rejected"); passed++;
            System.out.println("[PASS] grade is recorded\n[PASS] average grade calculated\n[PASS] duplicate grade in same week rejected\n[PASS] invalid mark rejected");
        } catch (Exception ex) { failed++; System.out.println("[FAIL] " + ex.getMessage()); log.error("Autotest exception", ex); }
        System.out.println("Autotests: " + passed + " passed, " + failed + " failed.");
        log.log("AUTOTESTS result: " + passed + " passed, " + failed + " failed");
        return failed == 0 && passed == 4;
    }
    private static void check(boolean condition, String name) { if (!condition) throw new IllegalStateException(name); }
}
