package lab2.controller;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/** Loads config.properties from the working directory or bundled resources. */
public class AppConfig {
    private final Properties values = new Properties();
    public AppConfig() throws IOException {
        Path external = Paths.get("config.properties");
        if (Files.isRegularFile(external)) {
            try (InputStream in = Files.newInputStream(external)) { values.load(in); }
        } else {
            try (InputStream in = AppConfig.class.getResourceAsStream("/config.properties")) {
                if (in == null) throw new IOException("config.properties was not found in the project resources or working directory");
                values.load(in);
            }
        }
    }
    public String get(String key, String fallback) { return values.getProperty(key, fallback).trim(); }
    public boolean getBoolean(String key, boolean fallback) { return Boolean.parseBoolean(get(key, String.valueOf(fallback))); }
}
