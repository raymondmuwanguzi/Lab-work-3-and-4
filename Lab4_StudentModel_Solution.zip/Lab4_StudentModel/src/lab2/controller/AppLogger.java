package lab2.controller;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Append-only timestamped log used by Lab 4. */
public class AppLogger {
    private final Path path;
    private final boolean debug;
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public AppLogger(String fileName, boolean debug) throws IOException {
        path = Paths.get(fileName); this.debug = debug;
        if (path.getParent() != null) Files.createDirectories(path.getParent());
        if (!Files.exists(path)) Files.createFile(path);
    }
    public synchronized void log(String message) {
        try {
            String line = LocalDateTime.now().format(FORMAT) + " | " + message + System.lineSeparator();
            Files.write(path, line.getBytes(StandardCharsets.UTF_8), StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException ex) { System.err.println("Cannot write log: " + ex.getMessage()); }
    }
    public void debug(String message) { if (debug) log("DEBUG | " + message); }
    public void error(String message, Exception ex) { log("ERROR | " + message + " | " + ex.getClass().getSimpleName() + ": " + ex.getMessage()); }
}
