package lab2.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lab2.model.*;

/** Text-file persistence for the complete Lab 2 semester model. */
public class ModelRepository {
    private final Path path;
    private final AppLogger logger;
    public ModelRepository(String fileName, AppLogger logger) { this.path = Paths.get(fileName); this.logger = logger; }
    private static String enc(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String dec(String s) { return new String(Base64.getDecoder().decode(s), StandardCharsets.UTF_8); }
    public void save(SemesterModel model) throws IOException {
        if (path.getParent() != null) Files.createDirectories(path.getParent());
        try (BufferedWriter out = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
            out.write("LAB4_STUDENT_MODEL\t1"); out.newLine();
            for (Teacher t : model.getTeachers()) out.write("T\t"+enc(t.getName())+"\t"+t.getAge()+"\t"+t.getGender().name()+"\t"+enc(t.getSubject().getTitle())+"\n");
            for (Parent p : model.getParents()) out.write("P\t"+enc(p.getName())+"\t"+p.getAge()+"\t"+p.getGender().name()+"\n");
            for (Student s : model.getStudents()) {
                String parent = s.getParent() == null ? "" : s.getParent().getName();
                out.write("S\t"+enc(s.getName())+"\t"+s.getAge()+"\t"+s.getGender().name()+"\t"+enc(parent)+"\t"+s.getBonus()+"\n");
                for (Subject subject : model.getSubjects()) for (Grade g : s.getGrades(subject))
                    out.write("G\t"+enc(s.getName())+"\t"+g.getValue()+"\t"+g.getWeek()+"\t"+enc(g.getSubject().getTitle())+"\t"+enc(g.getTeacher().getName())+"\n");
            }
        }
        logger.log("WRITE database file=" + path.toAbsolutePath() + ", students=" + model.getStudents().size());
    }
    public boolean load(SemesterModel model) throws IOException {
        if (!Files.isRegularFile(path)) return false;
        List<String[]> rows = new ArrayList<String[]>();
        try (BufferedReader in = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String line; boolean first = true;
            while ((line = in.readLine()) != null) { if (first) { first = false; if (!line.equals("LAB4_STUDENT_MODEL\t1")) throw new IOException("Unsupported database format"); continue; } if (!line.trim().isEmpty()) rows.add(line.split("\t", -1)); }
        }
        model.clearAll();
        Map<String, Teacher> teachers = new HashMap<String, Teacher>();
        Map<String, Student> students = new HashMap<String, Student>();
        Map<String, Parent> parents = new HashMap<String, Parent>();
        Map<String, String> parentLinks = new HashMap<String, String>();
        for (String[] r : rows) if (r[0].equals("T")) { Subject sub = new Subject(dec(r[4])); Teacher t = new Teacher(dec(r[1]), Integer.parseInt(r[2]), Gender.valueOf(r[3]), sub); model.addTeacher(t); teachers.put(t.getName(), t); }
        for (String[] r : rows) if (r[0].equals("P")) { Parent p = new Parent(dec(r[1]), Integer.parseInt(r[2]), Gender.valueOf(r[3])); model.addParent(p); parents.put(p.getName(), p); }
        for (String[] r : rows) if (r[0].equals("S")) { Student s = new Student(dec(r[1]), Integer.parseInt(r[2]), Gender.valueOf(r[3])); model.addStudent(s); students.put(s.getName(), s); parentLinks.put(s.getName(), dec(r[4])); if (r.length > 5) { int bonus = Integer.parseInt(r[5]); if (bonus > 0) s.receiveBonus(bonus); } }
        for (Map.Entry<String, String> e : parentLinks.entrySet()) { Parent p = parents.get(e.getValue()); Student s = students.get(e.getKey()); if (p != null && s != null) p.addChild(s); }
        for (String[] r : rows) if (r[0].equals("G")) { Student s = students.get(dec(r[1])); Teacher t = teachers.get(dec(r[5])); if (s != null && t != null) s.addGrade(new Grade(Integer.parseInt(r[2]), Integer.parseInt(r[3]), t.getSubject(), t)); }
        logger.log("READ database file=" + path.toAbsolutePath() + ", students=" + model.getStudents().size());
        return true;
    }
}
