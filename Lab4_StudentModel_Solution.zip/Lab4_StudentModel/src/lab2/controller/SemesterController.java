package lab2.controller;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import lab2.model.*;
import lab2.view.ConsoleView;

/** MVC controller: authentication, menu commands, model operations and file persistence. */
public class SemesterController {
    public static final int WEEKS = 14;
    private final SemesterModel model; private final ConsoleView view; private final Scanner input = new Scanner(System.in);
    private final AppConfig config; private final AppLogger logger; private final ModelRepository repository;
    private boolean root;
    public SemesterController(SemesterModel model, ConsoleView view, long seed) {
        this.model = model; this.view = view;
        try { config = new AppConfig(); logger = new AppLogger(config.get("logFile", "logs/application.log"), config.getBoolean("debug", false)); repository = new ModelRepository(config.get("dataFile", "data/students-db.txt"), logger); }
        catch (IOException ex) { throw new IllegalStateException("Cannot initialize application: " + ex.getMessage(), ex); }
    }
    public void run() {
        try {
            // Load settings before showing the main menu.
            AppConfig cfg = config;
            AppLogger log = logger;
            ModelRepository repo = repository;
            String configuredUser = cfg.get("username", "student");
            log.log("PROGRAM START; configured login=" + configuredUser);
            System.out.println("Welcome — " + configuredUser);
            if (!authenticate()) { log.log("Authentication failed; program terminated"); return; }
            if (cfg.getBoolean("autotests", false)) AutoTests.run(log);
            if (cfg.getBoolean("debug", false)) log.debug("Debug mode enabled; user=" + configuredUser + ", group=" + cfg.get("group", "user"));
            boolean running = true;
            while (running) {
                showMenu();
                int choice = readInt("Choose: ");
                try {
                    switch (choice) {
                        case 1: listStudents(); break;
                        case 2: addStudent(); break;
                        case 3: changeStudent(); break;
                        case 4: deleteStudent(); break;
                        case 5: save(); break;
                        case 6: load(); break;
                        case 7: showFullModel(); break;
                        case 8: if (root) AutoTests.run(log); else view.showMessage("Access denied."); break;
                        case 9: if (root) log.log("DEBUG MENU requested by " + configuredUser + "; students=" + model.getStudents().size()); else view.showMessage("Access denied."); break;
                        case 0: running = false; break;
                        default: view.showMessage("Unknown menu item.");
                    }
                } catch (Exception ex) { view.showMessage("Error: " + ex.getMessage()); log.error("Operation failed", ex); }
            }
            log.log("PROGRAM END; login=" + configuredUser);
        } catch (Exception ex) { System.err.println("Fatal error: " + ex.getMessage()); logger.error("Fatal application error", ex); }
        finally { input.close(); }
    }
    private boolean authenticate() {
        String expectedUser = config.get("username", "student"); String expectedPassword = config.get("password", "student123");
        String group = config.get("group", "user");
        for (int attempt = 1; attempt <= 3; attempt++) {
            System.out.print("Login: "); String user = input.nextLine().trim();
            System.out.print("Password: "); String password = input.nextLine();
            if (expectedUser.equals(user) && expectedPassword.equals(password)) { root = "root".equalsIgnoreCase(group); logger.log("Authenticated login=" + user + ", group=" + group); return true; }
            System.out.println("Incorrect login or password. Attempts left: " + (3 - attempt)); logger.log("Authentication failure for login=" + user);
        }
        return false;
    }
    private void showMenu() {
        view.showTitle("STUDENT SEMESTER MODEL — LAB 4");
        System.out.println("1. List students\n2. Add student\n3. Change student\n4. Delete student\n5. Save model to database file\n6. Load model from database file\n7. Show complete model");
        if (root) System.out.println("8. Autotests (root)\n9. Debug information (root)");
        System.out.println("0. Exit");
    }
    private void listStudents() {
        List<Student> students = model.getStudents();
        if (students.isEmpty()) { view.showMessage("No students loaded. Load the database or add students."); return; }
        for (int i=0; i<students.size(); i++) { Student s=students.get(i); System.out.println((i+1)+". "+s.getName()+", age="+s.getAge()+", gender="+s.getGender()+", average="+String.format(java.util.Locale.US,"%.2f",s.getAverageGrade())); }
    }
    private void addStudent() {
        String name = readText("Student name: "); int age = readInt("Age: "); Gender gender = readGender();
        Student student = new Student(name, age, gender); model.addStudent(student);
        view.showMessage("Student added. To assign a parent or grades, extend the model through Lab 2 entities."); logger.log("ADD student="+name);
    }
    private void changeStudent() {
        Student s = selectStudent(); if (s == null) return;
        String name = readText("New name ["+s.getName()+"]: "); int age = readInt("New age: "); Gender gender = readGender();
        String old=s.getName(); s.setName(name); s.setAge(age); s.setGender(gender);
        view.showMessage("Student updated."); logger.log("UPDATE student="+old+" -> "+name);
    }
    private void deleteStudent() {
        Student s=selectStudent(); if (s==null) return; String name=s.getName(); model.removeStudent(s); view.showMessage("Student deleted: "+name); logger.log("DELETE student="+name);
    }
    private Student selectStudent() {
        if (model.getStudents().isEmpty()) { view.showMessage("Student list is empty."); return null; }
        listStudents(); int n=readInt("Student number: "); if(n<1 || n>model.getStudents().size()) { view.showMessage("Invalid student number."); return null; } return model.getStudents().get(n-1);
    }
    private void save() throws IOException { repository.save(model); view.showMessage("Model saved to "+config.get("dataFile","data/students-db.txt")); }
    private void load() throws IOException { if(repository.load(model)) view.showMessage("Model loaded. Students read: "+model.getStudents().size()); else view.showMessage("Database file not found. Add students and save first."); }
    private void showFullModel() { view.showParticipants(model); view.showJournal(model); view.showAverageTable(model); view.showResults(model); view.showTotals(model); }
    private Gender readGender() { while(true) { String s=readText("Gender (M/F): "); if(s.equalsIgnoreCase("M")||s.equalsIgnoreCase("MALE")) return Gender.MALE; if(s.equalsIgnoreCase("F")||s.equalsIgnoreCase("FEMALE")) return Gender.FEMALE; System.out.println("Enter M or F."); } }
    private String readText(String prompt) { System.out.print(prompt); return input.nextLine().trim(); }
    private int readInt(String prompt) { while(true) { System.out.print(prompt); String s=input.nextLine().trim(); try { return Integer.parseInt(s); } catch(NumberFormatException ex) { System.out.println("Enter a whole number."); } } }
}
