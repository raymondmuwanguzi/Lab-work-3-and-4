# Lab 4 — Student Semester Model (MVC)

This project extends the supplied Lab 2 student-semester model. It keeps the MVC packages:
- `lab2.model` — students, parents, teachers, subjects, grades and semester model;
- `lab2.view` — console presentation;
- `lab2.controller` — menu, authentication, file repository, logging and autotests.

## Run in Eclipse
1. Import `Lab4_StudentModel` as an existing Java project (or create a Java project and copy `src`).
2. Ensure `src` is the source folder and Java 8+ is selected.
3. Run `lab2.Main`.
4. Default login: `student`; password: `student123`. Values can be changed in `config.properties`.

## Lab 4 functionality
- Reads settings before authentication/menu (`username`, `password`, `group`, `debug`, `autotests`).
- `root` sees Debug and Autotests menu items; `user` does not.
- Autotests run before the menu when `autotests=true`; results are printed and appended to `logs/application.log`.
- Saves and loads the model in a readable, versioned text database at `data/students-db.txt`. The file stores teachers, parents, students, student-parent links, grades and teacher/subject links.
- CRUD menu for student records; complete model view and grade journal inherited from Lab 2.
- Log is append-only and timestamped.

The `data` and `logs` folders are created automatically when needed. `config.properties` in the project working directory takes precedence over the bundled resource.
