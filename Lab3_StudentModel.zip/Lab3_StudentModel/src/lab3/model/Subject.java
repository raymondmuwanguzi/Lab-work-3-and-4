package lab3.model;

/** A subject (discipline) taught during the semester. */
public class Subject {

    private final String title;

    public Subject(String title) {
        if (title == null || title.trim().isEmpty()) {
            throw new IllegalArgumentException("Subject title must not be empty");
        }
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Subject)) {
            return false;
        }
        return title.equals(((Subject) o).title);
    }

    @Override
    public int hashCode() {
        return title.hashCode();
    }

    @Override
    public String toString() {
        return title;
    }
}
