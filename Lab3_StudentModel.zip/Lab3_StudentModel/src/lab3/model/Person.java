package lab3.model;

/** Base class for every human in the model: name, age and gender. */
public abstract class Person {

    private final String name;
    private final int age;
    private final Gender gender;

    protected Person(String name, int age, Gender gender) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name must not be empty");
        }
        if (age <= 0) {
            throw new IllegalArgumentException("Age must be positive: " + age);
        }
        if (gender == null) {
            throw new IllegalArgumentException("Gender must not be null");
        }
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public Gender getGender() {
        return gender;
    }

    /** Common part of the description used by subclasses: name, age, gender. */
    @Override
    public String toString() {
        return name + ", age " + age + ", " + gender;
    }
}
