package lab3.model;

/** Gender of a person. */
public enum Gender {
    MALE("male"),
    FEMALE("female");

    private final String title;

    Gender(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        return title;
    }
}
