package lab3.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Checks whether the time of add() in an {@link ArrayList} depends on the moments when the
 * internal array grows. The growth moments are calculated for two rules:
 * <ul>
 * <li>the rule from the lab text: newCapacity = (oldCapacity * 3) / 2 + 1 (Java 6);</li>
 * <li>the rule of modern JDK (7 and later): newCapacity = oldCapacity + (oldCapacity / 2).</li>
 * </ul>
 * In both cases the first add() allocates an array of 10 elements. The very first add() is
 * excluded from the comparison because its time is mostly the cost of the first call.
 */
public class ArrayListGrowthAnalyzer {

    private static final int DEFAULT_CAPACITY = 10;
    private static final int SHOWN_POINTS = 8;

    /** @return the numbers (starting from 1) of the add() calls that make the array grow */
    public static List<Integer> growthPoints(int size, boolean labFormula) {
        List<Integer> points = new ArrayList<Integer>();
        int capacity = 0;
        for (int element = 1; element <= size; element++) {
            if (element > capacity) {
                if (capacity == 0) {
                    capacity = DEFAULT_CAPACITY;
                } else if (labFormula) {
                    capacity = (capacity * 3) / 2 + 1;
                } else {
                    capacity = capacity + (capacity >> 1);
                }
                points.add(element);
            }
        }
        return points;
    }

    /**
     * Compares the times of the add() calls that cause growth with the times of all other calls.
     *
     * @param addTimes times of all add() calls in the order of execution (nanoseconds)
     * @return lines of the report
     */
    public static List<String> analyze(long[] addTimes) {
        List<String> lines = new ArrayList<String>();
        lines.add("ArrayList, " + addTimes.length + " elements: add() time at the moments of array growth");
        if (addTimes.length < 2) {
            lines.add("  not enough data");
            return lines;
        }
        lines.add(describe(addTimes, true));
        lines.add(describe(addTimes, false));
        return lines;
    }

    private static String describe(long[] times, boolean labFormula) {
        List<Integer> points = growthPoints(times.length, labFormula);
        boolean[] growth = new boolean[times.length];
        int growthCount = 0;
        for (int point : points) {
            if (point > 1) { // skip the first add(): it only creates the array
                growth[point - 1] = true;
                growthCount++;
            }
        }
        long[] growthTimes = new long[growthCount];
        long[] otherTimes = new long[times.length - 1 - growthCount];
        int g = 0;
        int o = 0;
        for (int i = 1; i < times.length; i++) {
            if (growth[i]) {
                growthTimes[g++] = times[i];
            } else {
                otherTimes[o++] = times[i];
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(labFormula ? "  Rule (old*3)/2+1" : "  Rule old+old/2  ");
        sb.append(": growth at add #");
        for (int i = 1; i < points.size() && i <= SHOWN_POINTS; i++) {
            sb.append(i > 1 ? ", " : "").append(points.get(i));
        }
        sb.append(points.size() - 1 > SHOWN_POINTS ? ", ..." : "");
        sb.append(" (").append(growthCount).append(" times)");
        if (growthCount == 0 || otherTimes.length == 0) {
            sb.append(": not enough data");
            return sb.toString();
        }
        long growthMedian = OperationStats.median(growthTimes);
        long otherMedian = OperationStats.median(otherTimes);
        sb.append(String.format(Locale.US,
                "%n      growth adds: average %d ns, median %d ns; other adds: average %d ns, median %d ns;"
                        + " median ratio = %.1f",
                average(growthTimes), growthMedian, average(otherTimes), otherMedian,
                otherMedian == 0 ? 0.0 : (double) growthMedian / otherMedian));
        return sb.toString();
    }

    private static long average(long[] values) {
        long sum = 0;
        for (long v : values) {
            sum += v;
        }
        return values.length == 0 ? 0L : sum / values.length;
    }
}
