package lab3.controller;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Common class for error handling, messages and logging (Appendix 2 of the lab).
 * <ul>
 * <li>keeps the list of all registered errors, so the number of errors is always known;</li>
 * <li>writes the errors to the error log (java.util.logging, configured in logging.properties);</li>
 * <li>writes the operation logs of the experiments (one text file per experiment).</li>
 * </ul>
 */
public class ErrMsgLog {

    /** Folder for all log files. It must be the same as in logging.properties. */
    public static final String LOG_DIR = "logs";
    private static final String CONFIG_RESOURCE = "logging.properties";

    private final List<Exception> errList = new ArrayList<Exception>();
    private final Logger log;
    private FileHandler fallbackHandler; // used only if logging.properties was not found
    private BufferedWriter operationLog;

    public ErrMsgLog() throws IOException {
        Files.createDirectories(Paths.get(LOG_DIR));
        InputStream config = ErrMsgLog.class.getResourceAsStream(CONFIG_RESOURCE);
        Logger logger = Logger.getLogger(ErrMsgLog.class.getName());
        if (config != null) {
            try {
                LogManager.getLogManager().readConfiguration(config);
            } finally {
                config.close();
            }
        } else {
            // the resource was not copied next to the classes: configure the logger in code
            fallbackHandler = new FileHandler(LOG_DIR + "/err_log.txt", true);
            fallbackHandler.setFormatter(new SimpleFormatter());
            logger.setUseParentHandlers(false);
            logger.addHandler(fallbackHandler);
        }
        this.log = logger;
    }

    // ------------------------------------------------------------------ errors

    /** Adds the error to the list of errors. */
    public int addErr(Exception e) {
        errList.add(e);
        return errList.size();
    }

    /** Adds the error to the list of errors and writes it to the log. */
    public int addErrWithLog(Exception e) {
        errList.add(e);
        log.log(Level.WARNING, e.getClass().getSimpleName() + ": " + e.getMessage());
        return errList.size();
    }

    /** Number of registered errors. */
    public int getErrCount() {
        return errList.size();
    }

    /** Shows the text of the error. */
    public void showErrText(Exception e) {
        System.err.println(e.getMessage());
    }

    /**
     * Registers the error (list and log) and returns a new exception that can be thrown
     * to the upper level.
     */
    public Exception makeErr(Exception e) {
        addErrWithLog(e);
        return new Exception(e.getMessage(), e);
    }

    // ------------------------------------------------------------------ operation logs

    /** Starts a new log file with the given name in the log folder. */
    public void startOperationLog(String fileName) throws IOException {
        finishOperationLog();
        operationLog = new BufferedWriter(new OutputStreamWriter(
                Files.newOutputStream(Paths.get(LOG_DIR, fileName)), StandardCharsets.UTF_8));
    }

    /** Writes one line to the current log file. */
    public void writeOperationLine(String line) throws IOException {
        if (operationLog == null) {
            throw new IOException("The log file is not opened");
        }
        operationLog.write(line);
        operationLog.newLine();
    }

    /** Closes the current log file (does nothing if there is none). */
    public void finishOperationLog() throws IOException {
        if (operationLog != null) {
            BufferedWriter writer = operationLog;
            operationLog = null;
            writer.close();
        }
    }

    /** Releases the log files. Call it at the end of the program. */
    public void close() {
        try {
            finishOperationLog();
        } catch (IOException e) {
            System.err.println("Cannot close the log file: " + e.getMessage());
        }
        if (fallbackHandler != null) {
            fallbackHandler.close();
        }
        LogManager.getLogManager().reset(); // closes the handlers of the error log
    }
}
