package lab3.controller;

import java.util.Arrays;

/** Execution times (in nanoseconds) of the operations of one type: count, total, average, median. */
public class OperationStats {

    private final String operation;
    private long[] times = new long[16];
    private int count;
    private long total;

    public OperationStats(String operation) {
        this.operation = operation;
    }

    public String getOperation() {
        return operation;
    }

    public void record(long nanos) {
        if (count == times.length) {
            times = Arrays.copyOf(times, count * 2);
        }
        times[count++] = nanos;
        total += nanos;
    }

    public int getCount() {
        return count;
    }

    public long getTotal() {
        return total;
    }

    /** Arithmetic mean of the times (0 if there are no operations). */
    public long getAverage() {
        return count == 0 ? 0L : total / count;
    }

    /** Median of the times (0 if there are no operations). */
    public long getMedian() {
        return median(getTimes());
    }

    /** Times of the operations in the order of their execution. */
    public long[] getTimes() {
        return Arrays.copyOf(times, count);
    }

    /** Median of an array (the array is sorted in place). */
    public static long median(long[] values) {
        if (values.length == 0) {
            return 0L;
        }
        Arrays.sort(values);
        int mid = values.length / 2;
        return values.length % 2 == 1 ? values[mid] : (values[mid - 1] + values[mid]) / 2;
    }
}
