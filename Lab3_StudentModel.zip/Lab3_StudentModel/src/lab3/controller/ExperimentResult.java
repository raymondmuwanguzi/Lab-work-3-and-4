package lab3.controller;

/** Result of one experiment: one collection type filled with {@code size} objects. */
public class ExperimentResult {

    private final String collectionName;
    private final int size;
    private final OperationStats addStats;
    private final OperationStats removeStats;

    public ExperimentResult(String collectionName, int size, OperationStats addStats,
            OperationStats removeStats) {
        this.collectionName = collectionName;
        this.size = size;
        this.addStats = addStats;
        this.removeStats = removeStats;
    }

    public String getCollectionName() {
        return collectionName;
    }

    public int getSize() {
        return size;
    }

    public OperationStats getAddStats() {
        return addStats;
    }

    public OperationStats getRemoveStats() {
        return removeStats;
    }
}
