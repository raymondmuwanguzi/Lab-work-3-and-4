package lab3.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Builds the text reports (summary tables) of the experiments. */
public final class ExperimentReport {

    private ExperimentReport() {
    }

    /** Table with total / average / median time of add and remove for every experiment (ns). */
    public static List<String> summaryLines(List<ExperimentResult> results) {
        List<String> lines = new ArrayList<String>();
        lines.add("Summary of the experiments (times in nanoseconds)");
        lines.add(String.format("%-11s %7s | %-6s %14s %12s %12s | %-6s %12s %12s %12s",
                "Collection", "Size", "add", "Total", "Average", "Median",
                "remove", "Total", "Average", "Median"));
        for (ExperimentResult r : results) {
            OperationStats a = r.getAddStats();
            OperationStats d = r.getRemoveStats();
            lines.add(String.format(Locale.US, "%-11s %7d | %-6d %14d %12d %12d | %-6d %12d %12d %12d",
                    r.getCollectionName(), r.getSize(),
                    a.getCount(), a.getTotal(), a.getAverage(), a.getMedian(),
                    d.getCount(), d.getTotal(), d.getAverage(), d.getMedian()));
        }
        lines.add("(columns after add / remove: number of operations, Total, Average, Median)");
        return lines;
    }

    /**
     * For every collection shows how much the average and the median time of an operation
     * grow when the size of the collection grows 10 times (regression of performance).
     */
    public static List<String> regressionLines(List<ExperimentResult> results) {
        List<String> lines = new ArrayList<String>();
        lines.add("Growth of the time of one operation when the size grows 10 times (ratio to the previous size)");
        lines.add(String.format("%-11s %7s | %10s %10s | %10s %10s",
                "Collection", "Size", "add avg", "add median", "rem avg", "rem median"));
        ExperimentResult previous = null;
        for (ExperimentResult r : results) {
            if (previous != null && previous.getCollectionName().equals(r.getCollectionName())) {
                lines.add(String.format(Locale.US, "%-11s %7d | %10.2f %10.2f | %10.2f %10.2f",
                        r.getCollectionName(), r.getSize(),
                        ratio(r.getAddStats().getAverage(), previous.getAddStats().getAverage()),
                        ratio(r.getAddStats().getMedian(), previous.getAddStats().getMedian()),
                        ratio(r.getRemoveStats().getAverage(), previous.getRemoveStats().getAverage()),
                        ratio(r.getRemoveStats().getMedian(), previous.getRemoveStats().getMedian())));
            }
            previous = r;
        }
        return lines;
    }

    private static double ratio(long value, long base) {
        return base == 0 ? 0.0 : (double) value / base;
    }
}
