package lab3.controller;

/** Checked exception: an experiment cannot be run with the given parameters. */
public class ExperimentException extends Exception {

    private static final long serialVersionUID = 1L;

    public ExperimentException(String message) {
        super(message);
    }

    public ExperimentException(String message, Throwable cause) {
        super(message, cause);
    }
}
