package lab3.controller;

import java.util.ArrayList;
import java.util.List;

import lab3.model.ParentMood;
import lab3.model.Student;

/** Result of the solvability check for one student. */
public class FeasibilityReport {

    private final Student student;
    private final ParentMood target;
    private final int gradeCount;
    private final double currentAverage;
    private final int freeSlots;
    private final double maxAverage;
    private final int fivesNeeded; // -1 if the target cannot be reached
    private final List<String> plan = new ArrayList<String>();
    private final List<String> alternatives = new ArrayList<String>();

    public FeasibilityReport(Student student, ParentMood target, int gradeCount, double currentAverage,
            int freeSlots, double maxAverage, int fivesNeeded) {
        this.student = student;
        this.target = target;
        this.gradeCount = gradeCount;
        this.currentAverage = currentAverage;
        this.freeSlots = freeSlots;
        this.maxAverage = maxAverage;
        this.fivesNeeded = fivesNeeded;
    }

    public Student getStudent() {
        return student;
    }

    public ParentMood getTarget() {
        return target;
    }

    public int getGradeCount() {
        return gradeCount;
    }

    public double getCurrentAverage() {
        return currentAverage;
    }

    /** How many more grades the student can still receive (all subjects together). */
    public int getFreeSlots() {
        return freeSlots;
    }

    /** The best average that is still possible (all remaining grades are 5). */
    public double getMaxAverage() {
        return maxAverage;
    }

    /** Minimal number of additional grades "5" that are enough; -1 if the target is unreachable. */
    public int getFivesNeeded() {
        return fivesNeeded;
    }

    public boolean isSolvable() {
        return fivesNeeded >= 0;
    }

    /** Which grades must be given so that the target is reached (empty if nothing is needed). */
    public List<String> getPlan() {
        return plan;
    }

    /** Admissible ways to get a solvable task if the target is unreachable. */
    public List<String> getAlternatives() {
        return alternatives;
    }
}
