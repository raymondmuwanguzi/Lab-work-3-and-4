package lab3;

import java.io.IOException;
import java.util.Scanner;

import lab3.controller.AppController;
import lab3.controller.ErrMsgLog;
import lab3.view.ConsoleView;

/** Entry point of laboratory work No. 3: exceptions and collections (extends Lab 2). */
public class Main {

    public static void main(String[] args) {
        ErrMsgLog errLog;
        try {
            errLog = new ErrMsgLog();
        } catch (IOException e) {
            System.err.println("Cannot start the logging: " + e.getMessage());
            return;
        }
        Scanner scanner = new Scanner(System.in);
        try {
            new AppController(new ConsoleView(), errLog, AppController.SEED).run(scanner);
        } finally {
            scanner.close();
            errLog.close();
        }
    }
}
