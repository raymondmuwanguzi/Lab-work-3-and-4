# Lab 3 - exceptions and collections (extends Lab 2)

Eclipse: File > Import > Existing Projects into Workspace > select this folder > run `lab3.Main`.
The 10 experiment logs and the error log are created in the `logs` folder of the project.
For 100000 elements the default heap is enough; if you get an out-of-memory message use VM argument `-Xmx1g`.

Command line (JDK 8+), from the project folder:

    mkdir out
    javac -d out $(find src -name "*.java")
    cp src/lab3/controller/logging.properties out/lab3/controller/
    java -cp out lab3.Main
